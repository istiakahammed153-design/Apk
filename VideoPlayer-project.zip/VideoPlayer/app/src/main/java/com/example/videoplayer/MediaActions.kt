package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Date

/**
 * File operations shared by the video list and the player: rename, delete, share, details,
 * hide into the private vault and restore from it. Android 10+ asks the user to confirm changes to
 * files owned by other apps, so those calls finish in [onActivityResult].
 */
class MediaActions(private val act: Activity) {

    interface Listener {
        fun onPlay(item: VideoItem) {}
        fun onDeleted(item: VideoItem) {}
        fun onRenamed(old: VideoItem, updated: VideoItem) {}
        fun onHiddenChanged(item: VideoItem) {}
        fun onFavoriteChanged(item: VideoItem) {}
    }

    companion object {
        const val REQ_DELETE = 9101
        const val REQ_WRITE = 9102
    }

    private val ui = Handler(Looper.getMainLooper())

    private var pendingDelete: VideoItem? = null
    private var deleteDone: ((Boolean) -> Unit)? = null
    private var pendingRenameItem: VideoItem? = null
    private var pendingRenameName: String = ""
    private var renameDone: ((VideoItem?) -> Unit)? = null

    private fun toast(s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ long-press menu

    fun showMenu(item: VideoItem, showPlay: Boolean, listener: Listener) {
        val labels = ArrayList<String>()
        val runs = ArrayList<() -> Unit>()
        fun add(label: String, run: () -> Unit) {
            labels.add(label)
            runs.add(run)
        }

        if (showPlay) add("Play") { listener.onPlay(item) }
        add("Rename") { promptRename(item, listener) }
        add("Delete") { confirmDelete(item, listener) }
        if (!item.isVault) {
            add("Share") { share(item) }
            val id = item.uri.toString()
            val fav = Prefs.isFavorite(act, id)
            add(if (fav) "Remove from favorites" else "Add to favorites") {
                Prefs.toggleFavorite(act, id)
                listener.onFavoriteChanged(item)
            }
            add("Hide (password protected)") { startHide(item, listener) }
        } else {
            add("Unhide (restore to gallery)") { startUnhide(item, listener) }
        }
        add("Details") { showDetails(item) }

        AlertDialog.Builder(act)
            .setTitle(item.name)
            .setItems(labels.toTypedArray()) { _, which -> runs[which]() }
            .show()
    }

    // ------------------------------------------------------------------ delete

    private fun confirmDelete(item: VideoItem, listener: Listener) {
        AlertDialog.Builder(act)
            .setTitle("Delete this file?")
            .setMessage(item.name + "\n\nThis cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                delete(item) { ok ->
                    if (ok) {
                        Prefs.forget(act, item.uri.toString())
                        listener.onDeleted(item)
                        toast("Deleted")
                    } else {
                        toast("Could not delete this video")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun delete(item: VideoItem, done: (Boolean) -> Unit) {
        if (item.isVault) {
            val p = item.path
            done(p != null && File(p).delete())
            return
        }
        val uri = item.uri
        if (uri.authority != MediaStore.AUTHORITY) {
            val ok = try {
                DocumentsContract.deleteDocument(act.contentResolver, uri)
            } catch (e: Exception) {
                false
            }
            done(ok)
            return
        }
        deleteDone = done
        pendingDelete = item
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(act.contentResolver, listOf(uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } else {
                val rows = act.contentResolver.delete(uri, null, null)
                finishDelete(rows > 0)
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_DELETE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishDelete(false)
                }
            } else {
                finishDelete(false)
            }
        } catch (e: Exception) {
            finishDelete(false)
        }
    }

    private fun finishDelete(ok: Boolean) {
        val cb = deleteDone
        deleteDone = null
        pendingDelete = null
        cb?.invoke(ok)
    }

    // ------------------------------------------------------------------ rename

    private fun sanitize(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        return cleaned
    }

    private fun promptRename(item: VideoItem, listener: Listener) {
        val dot = item.name.lastIndexOf('.')
        val ext = if (dot > 0) item.name.substring(dot) else ""
        val base = if (dot > 0) item.name.substring(0, dot) else item.name

        val input = EditText(act)
        input.setText(base)
        input.setSingleLine()
        input.setSelectAllOnFocus(true)
        val box = LinearLayout(act)
        box.setPadding(act.dp(22), act.dp(8), act.dp(22), act.dp(4))
        box.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        AlertDialog.Builder(act)
            .setTitle("Rename")
            .setView(box)
            .setPositiveButton("Rename") { _, _ ->
                val nn = sanitize(input.text.toString())
                if (nn.isEmpty()) {
                    toast("Name cannot be empty")
                } else {
                    rename(item, nn + ext) { updated ->
                        if (updated != null) {
                            listener.onRenamed(item, updated)
                            toast("Renamed")
                        } else {
                            toast("Could not rename this video")
                        }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun rename(item: VideoItem, newName: String, done: (VideoItem?) -> Unit) {
        if (item.isVault) {
            val p = item.path
            if (p == null) {
                done(null)
                return
            }
            val from = File(p)
            val target = File(from.parentFile, newName)
            if (target.exists()) {
                done(null)
                return
            }
            val ok = from.renameTo(target)
            done(
                if (ok) item.copy(uri = Uri.fromFile(target), name = newName, path = target.absolutePath)
                else null
            )
            return
        }
        if (item.uri.authority != MediaStore.AUTHORITY) {
            val nu = try {
                DocumentsContract.renameDocument(act.contentResolver, item.uri, newName)
            } catch (e: Exception) {
                null
            }
            done(if (nu != null) item.copy(uri = nu, name = newName) else null)
            return
        }
        renameDone = done
        pendingRenameItem = item
        pendingRenameName = newName
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createWriteRequest(act.contentResolver, listOf(item.uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_WRITE, null, 0, 0, 0)
            } else {
                finishRename(doRename())
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishRename(false)
                }
            } else {
                finishRename(false)
            }
        } catch (e: Exception) {
            finishRename(false)
        }
    }

    private fun doRename(): Boolean {
        val item = pendingRenameItem ?: return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingRenameName)
            act.contentResolver.update(item.uri, v, null, null) > 0
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                    // finishRename() will be called from onActivityResult
                    pendingRetryRename = true
                } catch (x: Exception) {
                    // give up
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }

    private var pendingRetryRename = false

    private fun finishRename(ok: Boolean) {
        if (pendingRetryRename && !ok) {
            // a permission prompt is on screen; the result arrives in onActivityResult
            return
        }
        val item = pendingRenameItem
        val cb = renameDone
        val name = pendingRenameName
        pendingRenameItem = null
        renameDone = null
        pendingRetryRename = false
        if (item == null || cb == null) return
        cb(if (ok) item.copy(name = name) else null)
    }

    // ------------------------------------------------------------------ activity results

    /** Forward Activity.onActivityResult here. Returns true if the result belonged to us. */
    fun onActivityResult(requestCode: Int, resultCode: Int): Boolean {
        if (requestCode == REQ_DELETE) {
            if (resultCode == Activity.RESULT_OK && Build.VERSION.SDK_INT == 29) {
                val ok = try {
                    val u = pendingDelete?.uri
                    u != null && act.contentResolver.delete(u, null, null) > 0
                } catch (e: Exception) {
                    false
                }
                finishDelete(ok)
            } else {
                finishDelete(resultCode == Activity.RESULT_OK)
            }
            return true
        }
        if (requestCode == REQ_WRITE) {
            // the user answered the permission prompt; stop waiting and try (or give up)
            pendingRetryRename = false
            if (resultCode == Activity.RESULT_OK) {
                finishRename(doRename())
            } else {
                finishRename(false)
            }
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ share and details

    fun share(item: VideoItem) {
        if (item.uri.scheme != "content") {
            toast("Unhide the video first to share it")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
        send.type = if (item.isAudio) "audio/*" else "video/*"
        send.putExtra(Intent.EXTRA_STREAM, item.uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.startActivity(Intent.createChooser(send, "Share video"))
    }

    fun showDetails(item: VideoItem) {
        val sb = StringBuilder()
        sb.append("Name: ").append(item.name).append('\n')
        if (item.isVault) {
            sb.append("Location: private vault\n")
        } else if (!item.path.isNullOrEmpty()) {
            sb.append("Path: ").append(item.path).append('\n')
            sb.append("Storage: ").append(if (item.isSdCard) "SD card" else "Internal").append('\n')
        }
        if (item.sizeBytes > 0) sb.append("Size: ").append(formatSize(item.sizeBytes)).append('\n')
        if (item.durationMs > 0) sb.append("Duration: ").append(formatTime(item.durationMs)).append('\n')
        if (item.width > 0 && item.height > 0) {
            sb.append("Resolution: ").append(item.width).append(" x ").append(item.height).append('\n')
        }
        if (item.dateAdded > 0) {
            sb.append("Added: ")
                .append(DateFormat.getDateTimeInstance().format(Date(item.dateAdded * 1000)))
                .append('\n')
        }
        AlertDialog.Builder(act)
            .setTitle("Details")
            .setMessage(sb.toString().trim())
            .setPositiveButton("OK", null)
            .show()
    }

    // ------------------------------------------------------------------ vault: hide / unhide

    private fun busy(title: String): AlertDialog {
        val box = LinearLayout(act)
        box.gravity = Gravity.CENTER
        box.setPadding(act.dp(24), act.dp(16), act.dp(24), act.dp(16))
        box.addView(ProgressBar(act))
        return AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false).show()
    }

    private fun startHide(item: VideoItem, listener: Listener) {
        val proceed = {
            AlertDialog.Builder(act)
                .setTitle("Hide file")
                .setMessage(
                    "Move \"" + item.name + "\" into the private vault?\n\n" +
                        "It will disappear from the gallery and file managers and can only be opened " +
                        "from the Hidden tab with your password. Android may ask you to confirm " +
                        "removing the original file."
                )
                .setPositiveButton("Hide") { _, _ -> doHide(item, listener) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        if (!Vault.hasPassword(act)) {
            VaultUi.create(act) { proceed() }
        } else {
            proceed()
        }
    }

    private fun doHide(item: VideoItem, listener: Listener) {
        val dlg = busy("Hiding...")
        Thread {
            var dest: File? = null
            var copied = false
            try {
                val d = Vault.uniqueFile(act, item.name)
                dest = d
                val total = if (item.sizeBytes > 0) item.sizeBytes else 1L
                val input = act.contentResolver.openInputStream(item.uri)
                if (input != null) {
                    input.use { src ->
                        FileOutputStream(d).use { out ->
                            val buf = ByteArray(256 * 1024)
                            var done = 0L
                            var lastPct = -1
                            while (true) {
                                val n = src.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                val pct = (done * 100 / total).toInt().coerceAtMost(100)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    ui.post { dlg.setTitle("Hiding... $pct%") }
                                }
                            }
                        }
                    }
                    copied = true
                }
            } catch (e: Exception) {
                copied = false
            }
            val copy = dest
            ui.post {
                try {
                    dlg.dismiss()
                } catch (e: Exception) {
                    // ignore
                }
                if (!copied) {
                    copy?.delete()
                    toast("Could not hide this video")
                } else {
                    delete(item) { ok ->
                        if (ok) {
                            Prefs.forget(act, item.uri.toString())
                            listener.onHiddenChanged(item)
                            toast("Video hidden")
                        } else {
                            copy?.delete()
                            toast("Cancelled. The video was not hidden.")
                        }
                    }
                }
            }
        }.start()
    }

    private fun startUnhide(item: VideoItem, listener: Listener) {
        val dlg = busy("Restoring...")
        Thread {
            val p = item.path
            var res: String? = null
            var src: File? = null
            if (p != null) {
                val f = File(p)
                src = f
                val dot = item.name.lastIndexOf('.')
                val ext = if (dot > 0) item.name.substring(dot + 1).lowercase() else ""
                val audio = item.isAudio || isAudioName(item.name)
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    ?: (if (audio) "audio/mpeg" else "video/mp4")
                val kind = if (audio) MediaSaver.Kind.AUDIO else MediaSaver.Kind.VIDEO
                res = MediaSaver.saveFile(act, f, item.name, mime, kind, "Restored")
            }
            val where = res
            val file = src
            ui.post {
                try {
                    dlg.dismiss()
                } catch (e: Exception) {
                    // ignore
                }
                if (where != null) {
                    file?.delete()
                    listener.onHiddenChanged(item)
                    toast("Restored to $where")
                } else {
                    toast("Could not restore this video")
                }
            }
        }.start()
    }
}
