package com.example.videoplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        private const val REQ_PERMISSION = 1
        private const val REQ_OPEN_FILE = 2
    }

    private val all = ArrayList<VideoItem>()
    private val shown = ArrayList<VideoItem>()
    private var favoritesOnly = false

    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private lateinit var btnAll: TextView
    private lateinit var btnFav: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = convertView ?: LayoutInflater.from(this@MainActivity)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            val item = shown[position]
            val t1 = view.findViewById<TextView>(android.R.id.text1)
            val t2 = view.findViewById<TextView>(android.R.id.text2)
            t1.text = item.name
            t1.setTextColor(Color.WHITE)
            t1.maxLines = 2
            val star = if (Prefs.isFavorite(this@MainActivity, item.uri.toString())) "★  " else ""
            t2.text = star + formatTime(item.durationMs) + "   " + formatSize(item.sizeBytes)
            t2.setTextColor(Color.parseColor("#B0B0B0"))
            return view
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listView)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnAll = findViewById(R.id.btnAll)
        btnFav = findViewById(R.id.btnFav)
        val btnOpen = findViewById<TextView>(R.id.btnOpen)

        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            PlaylistHolder.items = ArrayList(shown)
            PlaylistHolder.index = position
            startActivity(Intent(this, PlayerActivity::class.java))
        }

        btnOpen.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, REQ_OPEN_FILE)
        }
        btnAll.setOnClickListener {
            favoritesOnly = false
            applyFilter()
        }
        btnFav.setOnClickListener {
            favoritesOnly = true
            applyFilter()
        }

        ensurePermission()
    }

    override fun onResume() {
        super.onResume()
        applyFilter()
    }

    private fun neededPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun ensurePermission() {
        if (checkSelfPermission(neededPermission()) == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        } else {
            requestPermissions(arrayOf(neededPermission()), REQ_PERMISSION)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadVideos()
            } else {
                tvEmpty.text = "Allow video access to see your videos here.\nYou can still use \"Open file\"."
                tvEmpty.visibility = View.VISIBLE
            }
        }
    }

    private fun loadVideos() {
        Thread {
            val result = ArrayList<VideoItem>()
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE
            )
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    while (c.moveToNext()) {
                        val uri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            c.getLong(iId)
                        )
                        result.add(
                            VideoItem(
                                uri,
                                c.getString(iName) ?: "Video",
                                c.getLong(iDur),
                                c.getLong(iSize)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // leave the list empty; the user can still use "Open file"
            }
            runOnUiThread {
                all.clear()
                all.addAll(result)
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        shown.clear()
        if (favoritesOnly) {
            val favs = Prefs.favorites(this)
            for (v in all) if (favs.contains(v.uri.toString())) shown.add(v)
        } else {
            shown.addAll(all)
        }
        btnAll.setTextColor(if (favoritesOnly) Color.WHITE else Color.parseColor("#2ECC71"))
        btnFav.setTextColor(if (favoritesOnly) Color.parseColor("#2ECC71") else Color.WHITE)
        if (shown.isEmpty()) {
            if (favoritesOnly) tvEmpty.text = "No favorites yet"
            else if (all.isEmpty()) tvEmpty.text = "No videos found.\nTap \"Open file\" to pick one."
            tvEmpty.visibility = View.VISIBLE
        } else {
            tvEmpty.visibility = View.GONE
        }
        adapter.notifyDataSetChanged()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OPEN_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // not every provider allows persisting; playing now still works
            }
            PlaylistHolder.items = listOf(VideoItem(uri, queryName(this, uri), 0L, 0L))
            PlaylistHolder.index = 0
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}
