package com.example.videoplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        private const val REQ_PERMISSION = 1
        private const val REQ_OPEN_FILE = 2
        private const val REQ_HIDE_FILES = 3

        private const val F_ALL = 0
        private const val F_VIDEO = 1
        private const val F_AUDIO = 2
        private const val F_FAV = 3
        private const val F_INTERNAL = 4
        private const val F_SD = 5
        private const val F_HIDDEN = 6

        private const val SORT_DATE = 0
        private const val SORT_NAME = 1
        private const val SORT_SIZE = 2
        private const val SORT_DURATION = 3

        private const val ACCENT = "#2ECC71"
    }

    private val all = ArrayList<VideoItem>()
    private val vault = ArrayList<VideoItem>()
    private val shown = ArrayList<VideoItem>()

    private var filter = F_ALL
    private var query = ""
    private var vaultUnlocked = false
    private var openingPlayer = false
    private var permissionDenied = false

    private lateinit var actions: MediaActions
    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView
    private lateinit var tvCount: TextView
    private lateinit var etSearch: EditText
    private lateinit var btnHide: ImageButton
    private lateinit var chips: List<TextView>

    private val listener = object : MediaActions.Listener {
        override fun onPlay(item: VideoItem) {
            val pos = shown.indexOf(item)
            if (pos >= 0) play(pos)
        }

        override fun onDeleted(item: VideoItem) {
            refreshAll()
        }

        override fun onRenamed(old: VideoItem, updated: VideoItem) {
            refreshAll()
        }

        override fun onHiddenChanged(item: VideoItem) {
            refreshAll()
        }

        override fun onFavoriteChanged(item: VideoItem) {
            applyFilter()
        }

        override fun onVaultChanged() {
            refreshAll()
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(this@MainActivity)
                .inflate(R.layout.item_video, parent, false)
            val item = shown[position]
            val ivThumb = v.findViewById<ImageView>(R.id.ivThumb)
            val ivType = v.findViewById<ImageView>(R.id.ivType)
            val tvDuration = v.findViewById<TextView>(R.id.tvDuration)
            val vProgress = v.findViewById<View>(R.id.vProgress)
            val tvName = v.findViewById<TextView>(R.id.tvName)
            val tvMeta = v.findViewById<TextView>(R.id.tvMeta)
            val ivFav = v.findViewById<ImageView>(R.id.ivFav)

            // small file-type icon behind the thumbnail (shows when there is no picture, e.g. audio, PDF)
            val kind = if (item.isVault) fileKind(item.name, item.mime) else if (item.isAudio) KIND_AUDIO else KIND_VIDEO
            when (kind) {
                KIND_VIDEO -> ivType.visibility = View.GONE
                else -> {
                    ivType.setImageResource(
                        when (kind) {
                            KIND_AUDIO -> R.drawable.ic_audio
                            KIND_IMAGE -> R.drawable.ic_image
                            else -> R.drawable.ic_file
                        }
                    )
                    ivType.visibility = View.VISIBLE
                }
            }
            Thumbs.load(this@MainActivity, item, ivThumb)
            tvName.text = item.name

            if (item.durationMs > 0) {
                tvDuration.text = formatTime(item.durationMs)
                tvDuration.visibility = View.VISIBLE
            } else {
                tvDuration.visibility = View.GONE
            }

            // thin "watched so far" bar under the thumbnail
            val id = item.prefKey
            val resume = Prefs.resume(this@MainActivity, id)
            val lp = vProgress.layoutParams
            if (resume > 0 && item.durationMs > 0 && resume < item.durationMs * 0.97) {
                lp.width = (dp(128) * resume / item.durationMs).toInt().coerceAtLeast(dp(4))
                vProgress.visibility = View.VISIBLE
            } else {
                lp.width = 0
                vProgress.visibility = View.GONE
            }
            vProgress.layoutParams = lp

            val parts = ArrayList<String>()
            val size = formatSize(item.sizeBytes)
            if (size.isNotEmpty()) parts.add(size)
            val res = resolutionLabel(item.width, item.height)
            if (res.isNotEmpty() && kind == KIND_VIDEO) parts.add(res)
            if (item.isVault && (kind == KIND_PDF || kind == KIND_TEXT || kind == KIND_OTHER || kind == KIND_IMAGE)) {
                parts.add(kindLabel(kind))
            }
            if (item.isSdCard) parts.add("SD card")
            tvMeta.text = parts.joinToString("  •  ")

            ivFav.visibility = if (Prefs.isFavorite(this@MainActivity, id)) View.VISIBLE else View.GONE
            return v
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        actions = MediaActions(this)

        listView = findViewById(R.id.listView)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvCount = findViewById(R.id.tvCount)
        etSearch = findViewById(R.id.etSearch)
        chips = listOf(
            findViewById<TextView>(R.id.chipAll),
            findViewById<TextView>(R.id.chipVideo),
            findViewById<TextView>(R.id.chipAudio),
            findViewById<TextView>(R.id.chipFav),
            findViewById<TextView>(R.id.chipInternal),
            findViewById<TextView>(R.id.chipSd),
            findViewById<TextView>(R.id.chipHidden)
        )
        setupChips()

        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ -> play(position) }
        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position in 0 until shown.size) actions.showMenu(shown[position], true, listener)
            true
        }

        findViewById<ImageButton>(R.id.btnOpen).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "video/*", "audio/*", "application/x-matroska", "application/ogg",
                    "application/mp4", "application/octet-stream"
                )
            )
            startActivityForResult(i, REQ_OPEN_FILE)
        }
        btnHide = findViewById(R.id.btnHide)
        btnHide.setOnClickListener { pickFilesToHide() }
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener { toggleSearch() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                applyFilter()
            }
        })

        for ((index, chip) in chips.withIndex()) {
            chip.setOnClickListener { selectFilter(index) }
        }

        // plain copies of hidden files must never survive a crash or a force-stop
        Thread { Vault.wipeTemp(applicationContext) }.start()

        if (!hasPermission()) requestPermissions(neededPermissions(), REQ_PERMISSION)
    }

    override fun onResume() {
        super.onResume()
        openingPlayer = false
        // the vault locks again when the app was left (but not while we only went to the player or the picker);
        // it also locks if a child screen (player, viewer) locked it because the app went to the background
        if (vaultUnlocked && !Vault.isUnlocked()) lockVault()
        if (!vaultUnlocked) {
            Vault.lock()
            if (filter == F_HIDDEN) filter = F_ALL
        }
        if (hasPermission()) {
            loadVideos()
        } else {
            applyFilter()
        }
        if (vaultUnlocked) loadVault()
    }

    override fun onStop() {
        super.onStop()
        if (!openingPlayer) lockVault()
    }

    override fun onBackPressed() {
        if (etSearch.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ permissions

    private fun neededPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO
        )
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
    }

    private fun hasPermission(): Boolean =
        checkSelfPermission(neededPermissions()[0]) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSION) {
            if (hasPermission()) {
                permissionDenied = false
                loadVideos()
            } else {
                permissionDenied = true
                applyFilter()
            }
        }
    }

    // ------------------------------------------------------------------ loading

    @Suppress("DEPRECATION")
    private fun loadVideos() {
        Thread {
            val result = ArrayList<VideoItem>()
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT
            )
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val iData = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                    val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                    while (c.moveToNext()) {
                        val uri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            c.getLong(iId)
                        )
                        val path = c.getString(iData)
                        result.add(
                            VideoItem(
                                uri,
                                c.getString(iName) ?: "Video",
                                c.getLong(iDur),
                                c.getLong(iSize),
                                path,
                                c.getLong(iDate),
                                c.getInt(iW),
                                c.getInt(iH),
                                isSdPath(path),
                                false
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // leave the list empty; the user can still use "Open file"
            }
            // audio files (music, recordings...) are listed too when the permission allows it
            try {
                val canReadAudio = Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (canReadAudio) loadAudio(result)
            } catch (e: Exception) {
                // audio simply stays out of the list
            }
            runOnUiThread {
                all.clear()
                all.addAll(result)
                applyFilter()
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun loadAudio(result: ArrayList<VideoItem>) {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection = MediaStore.Audio.Media.IS_RINGTONE + "=0 AND " +
            MediaStore.Audio.Media.IS_NOTIFICATION + "=0 AND " +
            MediaStore.Audio.Media.IS_ALARM + "=0"
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            MediaStore.Audio.Media.DATE_ADDED + " DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val uri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    c.getLong(iId)
                )
                val path = c.getString(iData)
                result.add(
                    VideoItem(
                        uri,
                        c.getString(iName) ?: "Audio",
                        c.getLong(iDur),
                        c.getLong(iSize),
                        path,
                        c.getLong(iDate),
                        0,
                        0,
                        isSdPath(path),
                        false,
                        true
                    )
                )
            }
        }
    }

    private fun isSdPath(path: String?): Boolean {
        if (path == null) return false
        return path.startsWith("/storage/") &&
            !path.startsWith("/storage/emulated/") &&
            !path.startsWith("/storage/self/")
    }

    private fun loadVault() {
        Thread {
            val list = Vault.list(this)
            runOnUiThread {
                vault.clear()
                vault.addAll(list)
                applyFilter()
            }
        }.start()
    }

    private fun refreshAll() {
        if (hasPermission()) loadVideos()
        if (vaultUnlocked) loadVault()
    }

    // ------------------------------------------------------------------ filters, sorting, search

    private fun setupChips() {
        val icons = intArrayOf(
            R.drawable.ic_playlist,
            R.drawable.ic_video,
            R.drawable.ic_audio,
            R.drawable.ic_star,
            R.drawable.ic_phone,
            R.drawable.ic_sd,
            R.drawable.ic_lock
        )
        for ((i, chip) in chips.withIndex()) {
            val d = getDrawable(icons[i])?.mutate()
            if (d != null) {
                d.setBounds(0, 0, dp(18), dp(18))
                chip.setCompoundDrawablesRelative(d, null, null, null)
            }
        }
    }

    private fun updateChips() {
        val accent = Color.parseColor(ACCENT)
        for ((i, chip) in chips.withIndex()) {
            val selected = i == filter
            chip.setBackgroundResource(if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip)
            val color = if (selected) accent else Color.WHITE
            chip.setTextColor(color)
            chip.compoundDrawableTintList = ColorStateList.valueOf(color)
        }
    }

    private fun selectFilter(f: Int) {
        if (f == F_HIDDEN) {
            openVault()
            return
        }
        if (filter == F_HIDDEN) lockVault()
        filter = f
        applyFilter()
    }

    /** Leaving the Hidden tab locks it again; the password is asked on every entry. */
    private fun lockVault() {
        vaultUnlocked = false
        vault.clear()
        Vault.lock()
        Thumbs.clear()
        Thread { Vault.wipeTemp(applicationContext) }.start()
    }

    private fun openVault() {
        if (!Vault.hasPassword(this)) {
            VaultUi.create(this) {
                vaultUnlocked = true
                showVault()
            }
        } else if (vaultUnlocked && Vault.isUnlocked()) {
            showVault()
        } else {
            VaultUi.unlock(this) {
                vaultUnlocked = true
                showVault()
            }
        }
    }

    private fun showVault() {
        filter = F_HIDDEN
        loadVault()
        applyFilter()
    }

    /** The Hidden tab hides itself from screenshots and the recent-apps screen, and shows the "hide files" button. */
    private fun updateVaultMode() {
        val inVault = filter == F_HIDDEN
        btnHide.visibility = if (inVault) View.VISIBLE else View.GONE
        if (inVault) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    /** Lets the user pick any files (pictures, PDFs, documents, videos ...) to encrypt into the vault. */
    private fun pickFilesToHide() {
        VaultUi.ensureUnlocked(this) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            openingPlayer = true // the picker must not lock the vault
            try {
                startActivityForResult(i, REQ_HIDE_FILES)
            } catch (e: Exception) {
                openingPlayer = false
                Toast.makeText(this, "No file picker available", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun applyFilter() {
        val source: List<VideoItem> = if (filter == F_HIDDEN) vault else all
        val favs = Prefs.favorites(this)
        val q = query.trim().lowercase(Locale.getDefault())
        shown.clear()
        for (v in source) {
            val ok = when (filter) {
                F_VIDEO -> !v.isAudio
                F_AUDIO -> v.isAudio
                F_FAV -> favs.contains(v.prefKey)
                F_INTERNAL -> !v.isSdCard
                F_SD -> v.isSdCard
                else -> true
            }
            if (ok && (q.isEmpty() || v.name.lowercase(Locale.getDefault()).contains(q))) shown.add(v)
        }
        when (Prefs.sortMode(this)) {
            SORT_NAME -> shown.sortBy { it.name.lowercase(Locale.getDefault()) }
            SORT_SIZE -> shown.sortByDescending { it.sizeBytes }
            SORT_DURATION -> shown.sortByDescending { it.durationMs }
            else -> shown.sortByDescending { it.dateAdded }
        }

        updateChips()
        updateVaultMode()
        tvCount.text = shown.size.toString() + (if (shown.size == 1) " file" else " files")
        if (shown.isEmpty()) {
            tvEmpty.text = when {
                permissionDenied && filter != F_HIDDEN ->
                    "Allow video access to see your videos here.\nYou can still use the folder icon to open a file."
                q.isNotEmpty() -> "No matching videos"
                filter == F_AUDIO -> "No audio files found."
                filter == F_VIDEO -> "No videos found."
                filter == F_FAV -> "No favorites yet.\nLong-press a video and choose Add to favorites."
                filter == F_HIDDEN -> "No hidden files.\nTap the lock button to hide any file, or long-press a video and choose Hide."
                filter == F_SD -> "No videos found on the SD card."
                filter == F_INTERNAL -> "No videos found in internal storage."
                else -> "No videos found.\nTap the folder icon to pick one."
            }
            tvEmpty.visibility = View.VISIBLE
        } else {
            tvEmpty.visibility = View.GONE
        }
        adapter.notifyDataSetChanged()
    }

    private fun toggleSearch() {
        if (etSearch.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            etSearch.visibility = View.VISIBLE
            etSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSearch() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etSearch.windowToken, 0)
        etSearch.setText("")
        etSearch.visibility = View.GONE
        query = ""
        applyFilter()
    }

    // ------------------------------------------------------------------ menu

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Sort by...")
        pm.menu.add(0, 2, 1, "Refresh")
        pm.menu.add(
            0, 3, 2,
            if (Prefs.showStatus(this)) "Clock & battery overlay: ON" else "Clock & battery overlay: OFF"
        )
        pm.menu.add(0, 4, 3, if (Vault.hasPassword(this)) "Change vault password" else "Set vault password")
        pm.menu.add(0, 6, 4, "Hide files (encrypt)...")
        pm.menu.add(0, 5, 5, "About")
        pm.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> showSortDialog()
                2 -> refreshAll()
                3 -> Prefs.putBool(this, "show_status", !Prefs.showStatus(this))
                4 -> if (Vault.hasPassword(this)) VaultUi.change(this) else VaultUi.create(this) {}
                6 -> pickFilesToHide()
                5 -> AlertDialog.Builder(this)
                    .setTitle("IA Player")
                    .setMessage(
                        "Version 2.2\n\nPlays video and audio files. Long-press a file for rename, " +
                            "delete, share, hide and more. Hidden files of any type are encrypted with AES-256 " +
                            "and need your password.\n\n" + getString(R.string.copyright)
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    private fun showSortDialog() {
        val labels = arrayOf("Newest first", "Name (A-Z)", "Largest first", "Longest first")
        val modes = intArrayOf(SORT_DATE, SORT_NAME, SORT_SIZE, SORT_DURATION)
        val checked = modes.indexOf(Prefs.sortMode(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Sort by")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                Prefs.putInt(this, "sort_mode", modes[which])
                applyFilter()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ------------------------------------------------------------------ playing

    private fun play(position: Int) {
        if (position !in 0 until shown.size) return
        if (shown[position].isVault) {
            openHidden(shown[position])
            return
        }
        PlaylistHolder.items = ArrayList(shown)
        PlaylistHolder.index = position
        openingPlayer = true
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    /** Opens a hidden file the right way for its type: player, picture/PDF/text viewer, or the file menu. */
    private fun openHidden(item: VideoItem) {
        if (!Vault.isUnlocked()) {
            lockVault()
            filter = F_ALL
            applyFilter()
            Toast.makeText(this, "The vault is locked", Toast.LENGTH_SHORT).show()
            return
        }
        when (fileKind(item.name, item.mime)) {
            KIND_VIDEO, KIND_AUDIO -> {
                val media = shown.filter {
                    val k = fileKind(it.name, it.mime)
                    k == KIND_VIDEO || k == KIND_AUDIO
                }
                PlaylistHolder.items = ArrayList(media)
                PlaylistHolder.index = media.indexOf(item).coerceAtLeast(0)
                openingPlayer = true
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            KIND_IMAGE, KIND_PDF, KIND_TEXT -> {
                ViewerHolder.item = item
                openingPlayer = true
                startActivity(Intent(this, SecureViewerActivity::class.java))
            }
            else -> {
                Toast.makeText(this, "No preview for this file type. Use Unhide to restore it.", Toast.LENGTH_LONG).show()
                actions.showMenu(item, false, listener)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (actions.onActivityResult(requestCode, resultCode)) return
        if (requestCode == REQ_HIDE_FILES) {
            if (resultCode != RESULT_OK || data == null) return
            val uris = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
            } else {
                data.data?.let { uris.add(it) }
            }
            actions.hidePicked(uris, listener)
            return
        }
        if (requestCode == REQ_OPEN_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // not every provider allows persisting; playing now still works
            }
            val picked = queryName(this, uri)
            PlaylistHolder.items = listOf(
                VideoItem(uri, picked, 0L, 0L, isAudio = isAudioName(picked))
            )
            PlaylistHolder.index = 0
            openingPlayer = true
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}
