package com.example.videoplayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaDataSource
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.PushbackInputStream
import java.io.RandomAccessFile
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * On-disk format of one encrypted vault file (".iav"):
 *
 *   0    magic "IAV1"                                   4 bytes
 *   4    file id (random)                               16 bytes
 *   20   header IV (random, new on every rewrite)       12 bytes
 *   32   encrypted header (JSON, padded) + GCM tag      2048 bytes
 *   2080 data chunks: every 64 KiB of the original file is encrypted on its own with AES-256-GCM
 *        (so seeking inside a video works) and carries its own 16-byte authentication tag.
 *
 * Keys are never stored. Each file gets its own data key and header key, derived with HMAC-SHA256
 * from the vault master key and the random file id. The chunk nonce is the chunk number, and the
 * "last chunk" flag is authenticated, so reordering, truncating or editing a file is detected.
 * The file name, type, size and duration live only inside the encrypted header.
 */
object VaultFormat {
    const val CHUNK = 64 * 1024
    const val TAG = 16
    const val HEADER_PLAIN = 2032
    const val HEADER_ENC = HEADER_PLAIN + TAG
    const val DATA_START = 4 + 16 + 12 + HEADER_ENC
    const val EXT = ".iav"
    val MAGIC = byteArrayOf('I'.code.toByte(), 'A'.code.toByte(), 'V'.code.toByte(), '1'.code.toByte())
}

/** Everything about a vault file that the user sees. Stored encrypted inside the file header. */
class VaultFileInfo(
    val name: String,
    val mime: String,
    val size: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val addedSec: Long
)

object VaultCrypto {
    private val rnd = SecureRandom()

    fun randomBytes(n: Int): ByteArray {
        val b = ByteArray(n)
        rnd.nextBytes(b)
        return b
    }

    fun hmac(key: ByteArray, vararg parts: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        for (p in parts) mac.update(p)
        return mac.doFinal()
    }

    /** PBKDF2 with HMAC-SHA256 (written out by hand because the JDK name is missing on Android 7). */
    fun pbkdf2(password: ByteArray, salt: ByteArray, iterations: Int, outLen: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(password, "HmacSHA256"))
        val hLen = 32
        val blocks = (outLen + hLen - 1) / hLen
        val out = ByteArray(blocks * hLen)
        for (b in 1..blocks) {
            mac.update(salt)
            mac.update(
                byteArrayOf(
                    (b ushr 24).toByte(), (b ushr 16).toByte(), (b ushr 8).toByte(), b.toByte()
                )
            )
            var u = mac.doFinal()
            val t = u.copyOf()
            for (i in 1 until iterations) {
                u = mac.doFinal(u)
                for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
            }
            System.arraycopy(t, 0, out, (b - 1) * hLen, hLen)
        }
        return out.copyOf(outLen)
    }

    fun newCipher(): Cipher = Cipher.getInstance("AES/GCM/NoPadding")

    private fun derive(master: ByteArray, label: String, fileId: ByteArray): SecretKeySpec =
        SecretKeySpec(hmac(master, label.toByteArray(Charsets.UTF_8), fileId), "AES")

    fun dataKey(master: ByteArray, fileId: ByteArray) = derive(master, "IAV-data", fileId)
    fun headerKey(master: ByteArray, fileId: ByteArray) = derive(master, "IAV-header", fileId)

    fun chunkNonce(index: Int): ByteArray {
        val n = ByteArray(12)
        n[8] = (index ushr 24).toByte()
        n[9] = (index ushr 16).toByte()
        n[10] = (index ushr 8).toByte()
        n[11] = index.toByte()
        return n
    }

    private fun headerAad(fileId: ByteArray): ByteArray = VaultFormat.MAGIC + fileId

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private fun shortName(name: String): String {
        val clean = name.ifBlank { "file" }
        if (clean.length <= 200) return clean
        return clean.substring(0, 180) + clean.substring(clean.length - 20)
    }

    private fun headerPlain(info: VaultFileInfo): ByteArray {
        val j = JSONObject()
        j.put("n", shortName(info.name))
        j.put("m", info.mime)
        j.put("s", info.size)
        j.put("d", info.durationMs)
        j.put("w", info.width)
        j.put("h", info.height)
        j.put("t", info.addedSec)
        val raw = j.toString().toByteArray(Charsets.UTF_8)
        if (raw.size > VaultFormat.HEADER_PLAIN) throw IOException("File name too long")
        val padded = ByteArray(VaultFormat.HEADER_PLAIN) { ' '.code.toByte() }
        System.arraycopy(raw, 0, padded, 0, raw.size)
        return padded
    }

    private fun parseHeader(plain: ByteArray): VaultFileInfo {
        val j = JSONObject(String(plain, Charsets.UTF_8).trim())
        return VaultFileInfo(
            j.getString("n"),
            j.optString("m", ""),
            j.getLong("s"),
            j.optLong("d", 0L),
            j.optInt("w", 0),
            j.optInt("h", 0),
            j.optLong("t", 0L)
        )
    }

    private fun sealHeader(master: ByteArray, fileId: ByteArray, info: VaultFileInfo): ByteArray {
        val iv = randomBytes(12)
        val c = newCipher()
        c.init(Cipher.ENCRYPT_MODE, headerKey(master, fileId), GCMParameterSpec(128, iv))
        c.updateAAD(headerAad(fileId))
        val enc = c.doFinal(headerPlain(info))
        return VaultFormat.MAGIC + fileId + iv + enc
    }

    /** Reads and decrypts only the small header. Throws if the password-derived key is wrong or the file is damaged. */
    fun readInfo(raf: RandomAccessFile, master: ByteArray): Pair<ByteArray, VaultFileInfo> {
        val head = ByteArray(4 + 16 + 12 + VaultFormat.HEADER_ENC)
        raf.seek(0)
        try {
            raf.readFully(head)
        } catch (e: java.io.EOFException) {
            throw IOException("Not a vault file")
        }
        for (i in 0 until 4) if (head[i] != VaultFormat.MAGIC[i]) throw IOException("Not a vault file")
        val fileId = head.copyOfRange(4, 20)
        val iv = head.copyOfRange(20, 32)
        val enc = head.copyOfRange(32, head.size)
        try {
            val c = newCipher()
            c.init(Cipher.DECRYPT_MODE, headerKey(master, fileId), GCMParameterSpec(128, iv))
            c.updateAAD(headerAad(fileId))
            return Pair(fileId, parseHeader(c.doFinal(enc)))
        } catch (e: GeneralSecurityException) {
            throw IOException("Wrong key or damaged file", e)
        } catch (e: org.json.JSONException) {
            throw IOException("Damaged header", e)
        }
    }

    /**
     * Encrypts [input] into [dest]. The data is written to a ".tmp" file first and renamed when complete,
     * so an interrupted copy never leaves a half-written vault file behind.
     */
    fun encrypt(
        master: ByteArray,
        input: InputStream,
        dest: File,
        name: String,
        mime: String,
        durationMs: Long,
        width: Int,
        height: Int,
        progress: ((Long) -> Unit)? = null
    ): VaultFileInfo {
        val fileId = randomBytes(16)
        val key = dataKey(master, fileId)
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        var ok = false
        try {
            var total = 0L
            RandomAccessFile(tmp, "rw").use { raf ->
                raf.setLength(0)
                raf.seek(VaultFormat.DATA_START.toLong())
                val pin = PushbackInputStream(input, 1)
                val buf = ByteArray(VaultFormat.CHUNK)
                val cipher = newCipher()
                var idx = 0
                while (true) {
                    val n = readFully(pin, buf)
                    if (n <= 0) break
                    var last = n < VaultFormat.CHUNK
                    if (!last) {
                        val b = pin.read()
                        if (b < 0) last = true else pin.unread(b)
                    }
                    cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, chunkNonce(idx)))
                    cipher.updateAAD(byteArrayOf(if (last) 1 else 0))
                    raf.write(cipher.doFinal(buf, 0, n))
                    total += n
                    idx++
                    progress?.invoke(total)
                    if (last) break
                }
                val info = VaultFileInfo(
                    name, mime, total, durationMs, width, height, System.currentTimeMillis() / 1000
                )
                raf.seek(0)
                raf.write(sealHeader(master, fileId, info))
            }
            // quick self-check before anything else (such as the original) is touched
            VaultReader.open(tmp, master).use { r ->
                if (r.size != total) throw IOException("Size mismatch")
                if (r.size > 0) r.readAt(maxOf(0L, r.size - 1), ByteArray(1), 0, 1)
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Could not finish the encrypted file")
            ok = true
            return VaultFileInfo(name, mime, total, durationMs, width, height, System.currentTimeMillis() / 1000)
        } finally {
            if (!ok) tmp.delete()
        }
    }

    /** Rewrites the (fixed-size) header of an existing file, for example after a rename. */
    fun updateHeader(master: ByteArray, file: File, change: (VaultFileInfo) -> VaultFileInfo) {
        RandomAccessFile(file, "rw").use { raf ->
            val (fileId, info) = readInfo(raf, master)
            val sealed = sealHeader(master, fileId, change(info))
            raf.seek(0)
            raf.write(sealed)
        }
    }
}

/** Random-access decrypting reader for one vault file. Not for sharing between threads without the lock it already has. */
class VaultReader private constructor(
    private val raf: RandomAccessFile,
    private val key: SecretKeySpec,
    val info: VaultFileInfo
) : Closeable {

    companion object {
        fun open(file: File, master: ByteArray): VaultReader {
            val raf = RandomAccessFile(file, "r")
            try {
                val (fileId, info) = VaultCrypto.readInfo(raf, master)
                if (info.size < 0) throw IOException("Damaged header")
                val chunks = (info.size + VaultFormat.CHUNK - 1) / VaultFormat.CHUNK
                val needed = VaultFormat.DATA_START + info.size + chunks * VaultFormat.TAG
                if (raf.length() < needed) throw IOException("File is truncated")
                return VaultReader(raf, VaultCrypto.dataKey(master, fileId), info)
            } catch (e: Exception) {
                try {
                    raf.close()
                } catch (x: Exception) {
                    // ignore
                }
                if (e is IOException) throw e
                throw IOException("Cannot open vault file", e)
            }
        }
    }

    val size: Long get() = info.size
    private val chunkCount = (info.size + VaultFormat.CHUNK - 1) / VaultFormat.CHUNK
    private val cipher = VaultCrypto.newCipher()
    private var cachedIndex = -1
    private var cached: ByteArray? = null

    /** Returns the number of bytes read, or -1 at the end of the file. */
    @Synchronized
    fun readAt(position: Long, dst: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (position < 0 || position >= size) return -1
        var p = position
        var o = off
        var left = minOf(len.toLong(), size - position).toInt()
        var total = 0
        while (left > 0) {
            val idx = (p / VaultFormat.CHUNK).toInt()
            val chunk = loadChunk(idx)
            val inChunk = (p - idx.toLong() * VaultFormat.CHUNK).toInt()
            val n = minOf(left, chunk.size - inChunk)
            if (n <= 0) break
            System.arraycopy(chunk, inChunk, dst, o, n)
            p += n
            o += n
            left -= n
            total += n
        }
        return if (total == 0) -1 else total
    }

    private fun loadChunk(idx: Int): ByteArray {
        val c = cached
        if (idx == cachedIndex && c != null) return c
        val last = idx.toLong() == chunkCount - 1
        val plainLen = if (last) (size - idx.toLong() * VaultFormat.CHUNK).toInt() else VaultFormat.CHUNK
        val enc = ByteArray(plainLen + VaultFormat.TAG)
        raf.seek(VaultFormat.DATA_START.toLong() + idx.toLong() * (VaultFormat.CHUNK + VaultFormat.TAG))
        raf.readFully(enc)
        val plain = try {
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, VaultCrypto.chunkNonce(idx)))
            cipher.updateAAD(byteArrayOf(if (last) 1 else 0))
            cipher.doFinal(enc)
        } catch (e: GeneralSecurityException) {
            throw IOException("Encrypted data is damaged or was changed", e)
        }
        cachedIndex = idx
        cached = plain
        return plain
    }

    override fun close() {
        try {
            raf.close()
        } catch (e: Exception) {
            // ignore
        }
        cached = null
    }
}

/** Plain InputStream view of a vault file (decrypts on the fly). */
class VaultInputStream(private val r: VaultReader, private val closeReader: Boolean = true) : InputStream() {
    private var pos = 0L

    override fun read(): Int {
        val b = ByteArray(1)
        val n = read(b, 0, 1)
        return if (n <= 0) -1 else (b[0].toInt() and 0xFF)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        val n = r.readAt(pos, b, off, len)
        if (n > 0) pos += n
        return n
    }

    override fun available(): Int = minOf(Int.MAX_VALUE.toLong(), maxOf(0L, r.size - pos)).toInt()

    override fun close() {
        if (closeReader) r.close()
    }
}

/** Lets MediaMetadataRetriever (thumbnails, durations) read an encrypted file without writing a plain copy. */
class VaultMediaDataSource(private val r: VaultReader) : MediaDataSource() {
    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (size == 0) return 0
        return r.readAt(position, buffer, offset, size)
    }

    override fun getSize(): Long = r.size

    override fun close() {
        // the reader is closed by whoever opened it
    }
}

/** ExoPlayer data source for "vault://" addresses: decrypts while playing, nothing is written to disk. */
@UnstableApi
class VaultDataSource(private val dir: File, private val master: ByteArray) : BaseDataSource(false) {
    private var reader: VaultReader? = null
    private var currentUri: Uri? = null
    private var position = 0L
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        currentUri = dataSpec.uri
        transferInitializing(dataSpec)
        val id = dataSpec.uri.pathSegments.firstOrNull()
        if (id == null || !Vault.isValidId(id)) throw IOException("Bad vault address")
        val r = VaultReader.open(File(dir, id + VaultFormat.EXT), master)
        reader = r
        if (dataSpec.position > r.size) {
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        position = dataSpec.position
        val available = r.size - position
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) minOf(dataSpec.length, available) else available
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val r = reader ?: return C.RESULT_END_OF_INPUT
        val n = r.readAt(position, buffer, offset, minOf(length.toLong(), remaining).toInt())
        if (n < 0) return C.RESULT_END_OF_INPUT
        position += n
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        currentUri = null
        try {
            reader?.close()
        } finally {
            reader = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }
}

/** Sends "vault://" addresses to [VaultDataSource] and everything else to the normal data source. */
@UnstableApi
class RoutingDataSource(private val normal: DataSource, private val vault: DataSource) : DataSource {
    private var active: DataSource? = null

    override fun addTransferListener(transferListener: TransferListener) {
        normal.addTransferListener(transferListener)
        vault.addTransferListener(transferListener)
    }

    override fun open(dataSpec: DataSpec): Long {
        val d = if (dataSpec.uri.scheme == Vault.SCHEME) vault else normal
        active = d
        return d.open(dataSpec)
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val d = active ?: return C.RESULT_END_OF_INPUT
        return d.read(buffer, offset, length)
    }

    override fun getUri(): Uri? = active?.uri

    override fun getResponseHeaders(): Map<String, List<String>> = active?.responseHeaders ?: emptyMap()

    override fun close() {
        try {
            active?.close()
        } finally {
            active = null
        }
    }
}

/** Decoding helpers for pictures stored in the vault. */
object VaultImages {
    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var s = 1
        while (w / (s * 2) >= maxSide || h / (s * 2) >= maxSide) s *= 2
        return s
    }

    /** Decodes a picture so that its longer side is at most about [maxSide] pixels. */
    fun decode(r: VaultReader, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeStream(VaultInputStream(r, false), null, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
        val bmp = BitmapFactory.decodeStream(VaultInputStream(r, false), null, opts) ?: return null
        return applyExifRotation(r, bmp)
    }

    private fun applyExifRotation(r: VaultReader, bmp: Bitmap): Bitmap {
        try {
            val exif = android.media.ExifInterface(VaultInputStream(r, false))
            val deg = when (
                exif.getAttributeInt(
                    android.media.ExifInterface.TAG_ORIENTATION,
                    android.media.ExifInterface.ORIENTATION_NORMAL
                )
            ) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg == 0f) return bmp
            val m = android.graphics.Matrix()
            m.postRotate(deg)
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Exception) {
            return bmp
        }
    }
}
