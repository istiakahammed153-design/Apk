package com.example.videoplayer

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

data class VideoItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val path: String? = null,
    val dateAdded: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val isSdCard: Boolean = false,
    val isVault: Boolean = false,
    val isAudio: Boolean = false
)

private val AUDIO_EXTENSIONS = setOf(
    "mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "amr", "awb", "wma",
    "mka", "mid", "midi", "ac3", "eac3", "ec3", "dts", "ape", "aif", "aiff", "caf"
)

/** True if the file name looks like an audio file (by extension or registered MIME type). */
fun isAudioName(name: String): Boolean {
    val dot = name.lastIndexOf('.')
    if (dot < 0) return false
    val ext = name.substring(dot + 1).lowercase(Locale.ROOT)
    if (AUDIO_EXTENSIONS.contains(ext)) return true
    val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
    return mime != null && mime.startsWith("audio/")
}

/** Hands the playlist from the list screen to the player screen without going through Intent extras. */
object PlaylistHolder {
    var items: List<VideoItem> = emptyList()
    var index: Int = 0
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun formatTime(ms: Long): String {
    val total = if (ms < 0) 0L else ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) {
        String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%02d:%02d", m, s)
    }
}

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return when {
        mb >= 1024 -> String.format(Locale.US, "%.2f GB", mb / 1024.0)
        mb >= 1 -> String.format(Locale.US, "%.0f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb)
    }
}

fun resolutionLabel(w: Int, h: Int): String {
    if (w <= 0 || h <= 0) return ""
    val side = minOf(w, h)
    return when {
        side >= 2000 -> "4K"
        side >= 1400 -> "2K"
        else -> side.toString() + "p"
    }
}

fun queryName(context: Context, uri: Uri): String {
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getString(0)
                if (!n.isNullOrBlank()) return n
            }
        }
    } catch (e: Exception) {
        // fall through to the path-based name
    }
    return uri.lastPathSegment ?: "Video"
}

/** Favorites, bookmarks, resume positions and all settings, kept in SharedPreferences. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("player_prefs", Context.MODE_PRIVATE)

    fun getInt(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun putInt(c: Context, key: String, v: Int) {
        sp(c).edit().putInt(key, v).apply()
    }

    fun getBool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun putBool(c: Context, key: String, v: Boolean) {
        sp(c).edit().putBoolean(key, v).apply()
    }

    fun getStr(c: Context, key: String, def: String): String = sp(c).getString(key, def) ?: def
    fun putStr(c: Context, key: String, v: String) {
        sp(c).edit().putString(key, v).apply()
    }

    fun sortMode(c: Context): Int = getInt(c, "sort_mode", 0)
    fun showStatus(c: Context): Boolean = getBool(c, "show_status", true)

    fun favorites(c: Context): Set<String> = sp(c).getStringSet("fav", emptySet()) ?: emptySet()

    fun isFavorite(c: Context, id: String): Boolean = favorites(c).contains(id)

    /** Returns true if the item is now a favorite, false if it was removed. */
    fun toggleFavorite(c: Context, id: String): Boolean {
        val set = favorites(c).toMutableSet()
        val added = if (set.contains(id)) {
            set.remove(id)
            false
        } else {
            set.add(id)
            true
        }
        sp(c).edit().putStringSet("fav", set).apply()
        return added
    }

    fun resume(c: Context, id: String): Long = sp(c).getLong("pos_$id", 0L)

    fun setResume(c: Context, id: String, positionMs: Long) {
        sp(c).edit().putLong("pos_$id", positionMs).apply()
    }

    fun bookmarks(c: Context, id: String): List<Long> {
        val raw = sp(c).getString("bm_$id", "") ?: ""
        return raw.split(",").mapNotNull { it.toLongOrNull() }.sorted()
    }

    fun addBookmark(c: Context, id: String, positionMs: Long) {
        val list = bookmarks(c, id).toMutableList()
        if (!list.contains(positionMs)) list.add(positionMs)
        sp(c).edit().putString("bm_$id", list.joinToString(",")).apply()
    }

    fun clearBookmarks(c: Context, id: String) {
        sp(c).edit().remove("bm_$id").apply()
    }

    /** Removes everything we remember about a video (after it was deleted or moved). */
    fun forget(c: Context, id: String) {
        val set = favorites(c).toMutableSet()
        set.remove(id)
        sp(c).edit()
            .putStringSet("fav", set)
            .remove("pos_$id")
            .remove("bm_$id")
            .apply()
    }
}

/** Loads video thumbnails in the background and keeps them in a memory cache. */
object Thumbs {
    private const val W = 320
    private const val H = 180

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8L).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, item: VideoItem, view: ImageView) {
        val key = item.uri.toString()
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val bmp = create(app, item)
            if (bmp != null) {
                cache.put(key, bmp)
                main.post {
                    if (view.tag == key) view.setImageBitmap(bmp)
                }
            }
        }
    }

    private fun create(ctx: Context, item: VideoItem): Bitmap? {
        try {
            if (!item.isVault && item.uri.scheme == "content" && Build.VERSION.SDK_INT >= 29) {
                return ctx.contentResolver.loadThumbnail(item.uri, Size(W, H), null)
            }
        } catch (e: Exception) {
            // fall back to grabbing a frame below
        }
        val r = MediaMetadataRetriever()
        try {
            if (item.uri.scheme == "file") {
                r.setDataSource(item.path ?: item.uri.path)
            } else {
                r.setDataSource(ctx, item.uri)
            }
            val atUs = if (item.durationMs > 4000) 2_000_000L else 0L
            val frame = r.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (frame != null) return ThumbnailUtils.extractThumbnail(frame, W, H)
            // audio files: use the embedded cover art if there is one
            val art = r.embeddedPicture ?: return null
            val cover = android.graphics.BitmapFactory.decodeByteArray(art, 0, art.size) ?: return null
            return ThumbnailUtils.extractThumbnail(cover, W, H)
        } catch (e: Exception) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}

/** Saves a finished file (clip, audio, screenshot, restored video) into the public media folders. */
object MediaSaver {
    enum class Kind(val base29: String, val legacyDir: String) {
        VIDEO("Movies", Environment.DIRECTORY_MOVIES),
        AUDIO("Music", Environment.DIRECTORY_MUSIC),
        IMAGE("Pictures", Environment.DIRECTORY_PICTURES)
    }

    /** Returns a short folder description such as "Movies/VideoPlayer", or null if saving failed. */
    fun saveFile(
        ctx: Context,
        src: File,
        displayName: String,
        mime: String,
        kind: Kind,
        folder: String = "VideoPlayer"
    ): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val collection = when (kind) {
                    Kind.VIDEO -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    Kind.AUDIO -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    Kind.IMAGE -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }
                val rel = kind.base29 + "/" + folder
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                values.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val resolver = ctx.contentResolver
                val dest = resolver.insert(collection, values)
                if (dest == null) {
                    null
                } else {
                    resolver.openOutputStream(dest)?.use { out ->
                        src.inputStream().use { it.copyTo(out) }
                    }
                    val done = ContentValues()
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(dest, done, null, null)
                    rel
                }
            } else {
                val canWrite = ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED
                val root = if (canWrite) {
                    Environment.getExternalStoragePublicDirectory(kind.legacyDir)
                } else {
                    ctx.getExternalFilesDir(kind.legacyDir)
                }
                if (root == null) {
                    null
                } else {
                    val dir = File(root, folder)
                    dir.mkdirs()
                    val dot = displayName.lastIndexOf('.')
                    val b = if (dot > 0) displayName.substring(0, dot) else displayName
                    val x = if (dot > 0) displayName.substring(dot) else ""
                    var target = File(dir, displayName)
                    var i = 1
                    while (target.exists()) {
                        target = File(dir, b + " (" + i + ")" + x)
                        i++
                    }
                    src.copyTo(target, overwrite = false)
                    MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), null, null)
                    kind.base29 + "/" + folder
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap, displayName: String): String? {
        val tmp = File(ctx.cacheDir, "shot_" + System.currentTimeMillis() + ".png")
        return try {
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            saveFile(ctx, tmp, displayName, "image/png", Kind.IMAGE, "VideoPlayer")
        } catch (e: Exception) {
            null
        } finally {
            tmp.delete()
        }
    }
}
