package com.example.videoplayer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.util.Locale

data class VideoItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long
)

/** Hands the playlist from the list screen to the player screen without going through Intent extras. */
object PlaylistHolder {
    var items: List<VideoItem> = emptyList()
    var index: Int = 0
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun formatTime(ms: Long): String {
    val total = if (ms < 0) 0L else ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) {
        String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%02d:%02d", m, s)
    }
}

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) {
        String.format(Locale.US, "%.2f GB", mb / 1024.0)
    } else {
        String.format(Locale.US, "%.0f MB", mb)
    }
}

fun queryName(context: Context, uri: Uri): String {
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getString(0)
                if (!n.isNullOrBlank()) return n
            }
        }
    } catch (e: Exception) {
        // fall through to the path-based name
    }
    return uri.lastPathSegment ?: "Video"
}

/** Favorites, bookmarks and resume positions, all kept in SharedPreferences. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("player_prefs", Context.MODE_PRIVATE)

    fun favorites(c: Context): Set<String> = sp(c).getStringSet("fav", emptySet()) ?: emptySet()

    fun isFavorite(c: Context, id: String): Boolean = favorites(c).contains(id)

    /** Returns true if the item is now a favorite, false if it was removed. */
    fun toggleFavorite(c: Context, id: String): Boolean {
        val set = favorites(c).toMutableSet()
        val added = if (set.contains(id)) {
            set.remove(id)
            false
        } else {
            set.add(id)
            true
        }
        sp(c).edit().putStringSet("fav", set).apply()
        return added
    }

    fun resume(c: Context, id: String): Long = sp(c).getLong("pos_$id", 0L)

    fun setResume(c: Context, id: String, positionMs: Long) {
        sp(c).edit().putLong("pos_$id", positionMs).apply()
    }

    fun bookmarks(c: Context, id: String): List<Long> {
        val raw = sp(c).getString("bm_$id", "") ?: ""
        return raw.split(",").mapNotNull { it.toLongOrNull() }.sorted()
    }

    fun addBookmark(c: Context, id: String, positionMs: Long) {
        val list = bookmarks(c, id).toMutableList()
        if (!list.contains(positionMs)) list.add(positionMs)
        sp(c).edit().putString("bm_$id", list.joinToString(",")).apply()
    }

    fun clearBookmarks(c: Context, id: String) {
        sp(c).edit().remove("bm_$id").apply()
    }
}
