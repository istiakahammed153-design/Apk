package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.InputType
import android.util.Base64
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * The private vault: hidden videos are moved into this app's own storage folder, which the gallery,
 * file managers and other apps cannot see. The password is stored only as a salted PBKDF2 hash.
 */
object Vault {
    private const val KEY_HASH = "vault_hash"
    private const val KEY_SALT = "vault_salt"

    fun dir(c: Context): File {
        val d = File(c.filesDir, "vault")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun hasPassword(c: Context): Boolean = Prefs.getStr(c, KEY_HASH, "").isNotEmpty()

    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 20000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
    }

    fun setPassword(c: Context, pw: String) {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        Prefs.putStr(c, KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
        Prefs.putStr(c, KEY_HASH, hash(pw, salt))
    }

    fun check(c: Context, pw: String): Boolean {
        val stored = Prefs.getStr(c, KEY_HASH, "")
        val saltText = Prefs.getStr(c, KEY_SALT, "")
        if (stored.isEmpty() || saltText.isEmpty()) return false
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            MessageDigest.isEqual(hash(pw, salt).toByteArray(), stored.toByteArray())
        } catch (e: Exception) {
            false
        }
    }

    fun uniqueFile(c: Context, name: String): File {
        val d = dir(c)
        var f = File(d, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(d, base + " (" + i + ")" + ext)
            i++
        }
        return f
    }

    /** Reads the vault folder. Call from a background thread. */
    fun list(c: Context): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val files = dir(c).listFiles() ?: return out
        for (f in files) {
            if (!f.isFile) continue
            var dur = 0L
            var w = 0
            var h = 0
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.absolutePath)
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            } catch (e: Exception) {
                // keep defaults
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                    // ignore
                }
            }
            out.add(
                VideoItem(
                    Uri.fromFile(f), f.name, dur, f.length(), f.absolutePath,
                    f.lastModified() / 1000, w, h, false, true, isAudioName(f.name)
                )
            )
        }
        return out
    }
}

/** Password dialogs for the vault. */
object VaultUi {

    private fun field(act: Activity, hint: String): EditText {
        val e = EditText(act)
        e.hint = hint
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setSingleLine()
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#CCCCCC"))
        return e
    }

    private fun box(act: Activity): LinearLayout {
        val b = LinearLayout(act)
        b.orientation = LinearLayout.VERTICAL
        b.setPadding(act.dp(22), act.dp(8), act.dp(22), act.dp(4))
        return b
    }

    private fun note(act: Activity, text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(Color.parseColor("#F0F0F0"))
        t.textSize = 13f
        t.setPadding(0, 0, 0, act.dp(8))
        return t
    }

    fun create(act: Activity, onDone: () -> Unit) {
        val b = box(act)
        b.addView(
            note(
                act,
                "Hidden videos are moved into this app's private storage. They disappear from the gallery " +
                    "and file managers and can only be opened here with this password.\n\n" +
                    "If you forget the password the videos cannot be opened, and uninstalling the app deletes them."
            )
        )
        val p1 = field(act, "Password (at least 4 characters)")
        val p2 = field(act, "Confirm password")
        b.addView(p1)
        b.addView(p2)
        val d = AlertDialog.Builder(act)
            .setTitle("Create vault password")
            .setView(b)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val a = p1.text.toString()
            val c = p2.text.toString()
            if (a.length < 4) {
                Toast.makeText(act, "Use at least 4 characters", Toast.LENGTH_SHORT).show()
            } else if (a != c) {
                Toast.makeText(act, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                Vault.setPassword(act, a)
                d.dismiss()
                onDone()
            }
        }
    }

    fun unlock(act: Activity, onSuccess: () -> Unit) {
        val b = box(act)
        val p = field(act, "Password")
        b.addView(p)
        val d = AlertDialog.Builder(act)
            .setTitle("Hidden videos")
            .setView(b)
            .setPositiveButton("Unlock", null)
            .setNegativeButton("Cancel", null)
            .show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            if (Vault.check(act, p.text.toString())) {
                d.dismiss()
                onSuccess()
            } else {
                Toast.makeText(act, "Wrong password", Toast.LENGTH_SHORT).show()
                p.setText("")
            }
        }
    }

    fun change(act: Activity) {
        val b = box(act)
        val old = field(act, "Current password")
        val n1 = field(act, "New password (at least 4 characters)")
        val n2 = field(act, "Confirm new password")
        b.addView(old)
        b.addView(n1)
        b.addView(n2)
        val d = AlertDialog.Builder(act)
            .setTitle("Change vault password")
            .setView(b)
            .setPositiveButton("Change", null)
            .setNegativeButton("Cancel", null)
            .show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val a = n1.text.toString()
            if (!Vault.check(act, old.text.toString())) {
                Toast.makeText(act, "Current password is wrong", Toast.LENGTH_SHORT).show()
            } else if (a.length < 4) {
                Toast.makeText(act, "Use at least 4 characters", Toast.LENGTH_SHORT).show()
            } else if (a != n2.text.toString()) {
                Toast.makeText(act, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                Vault.setPassword(act, a)
                d.dismiss()
                Toast.makeText(act, "Password changed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
