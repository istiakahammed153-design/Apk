package com.example.videoplayer

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns nothing itself: the player and its media session live in [PlaybackHolder] so the player screen can
 * come and go. This service only keeps the process alive and shows the notification-bar controls
 * (play / pause / previous / next / seek) while audio plays in the background.
 */
class PlaybackService : MediaSessionService() {

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        PlaybackHolder.session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val s = PlaybackHolder.session
        if (s != null && !isSessionAdded(s)) addSession(s)
        return super.onStartCommand(intent, flags, startId)
    }

    /** App swiped away from recents: keep playing only if audio is actually playing. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = PlaybackHolder.player
        if (p == null || !p.playWhenReady || !PlaybackHolder.backgroundAudio) {
            PlaybackHolder.release()
            stopSelf()
        }
    }

    override fun onDestroy() {
        PlaybackHolder.release()
        super.onDestroy()
    }
}

/** The one player (and session) shared by the player screen and the background service. */
object PlaybackHolder {
    var player: ExoPlayer? = null
    var session: MediaSession? = null
    var items: List<VideoItem> = emptyList()

    /** Mirrors the "background audio" button. */
    @Volatile
    var backgroundAudio = true

    var sleepMinutes = 0
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val sleepTask = Runnable {
        player?.pause()
        sleepMinutes = 0
    }

    fun scheduleSleep(minutes: Int) {
        handler.removeCallbacks(sleepTask)
        sleepMinutes = minutes
        if (minutes > 0) handler.postDelayed(sleepTask, minutes * 60_000L)
    }

    fun createSession(ctx: android.content.Context, p: ExoPlayer): MediaSession {
        val open = Intent(ctx, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_RESUME_SESSION, true)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            ctx, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val s = MediaSession.Builder(ctx, p).setId("ia_player").setSessionActivity(pi).build()
        session = s
        return s
    }

    fun release() {
        handler.removeCallbacks(sleepTask)
        sleepMinutes = 0
        try {
            session?.release()
        } catch (e: Exception) {
            // already released
        }
        try {
            player?.release()
        } catch (e: Exception) {
            // already released
        }
        session = null
        player = null
        items = emptyList()
    }
}
