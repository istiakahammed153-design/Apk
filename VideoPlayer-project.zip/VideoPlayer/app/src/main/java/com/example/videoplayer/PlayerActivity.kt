package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private class TrackEntry(
    val group: Tracks.Group,
    val index: Int,
    val label: String,
    val selected: Boolean
)

class PlayerActivity : Activity() {

    companion object {
        private const val REQ_SUBTITLE = 101
        private const val HIDE_DELAY_MS = 4000L
        private const val MODE_NONE = 0
        private const val MODE_SEEK = 1
        private const val MODE_BRIGHTNESS = 2
        private const val MODE_VOLUME = 3
    }

    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())

    // views
    private lateinit var root: View
    private lateinit var playerView: PlayerView
    private lateinit var nightOverlay: View
    private lateinit var controls: View
    private lateinit var btnUnlock: ImageButton
    private lateinit var tvOsd: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvPosition: TextView
    private lateinit var tvRemaining: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var btnMute: ImageButton
    private lateinit var btnLock: ImageButton
    private lateinit var btnSpeed: TextView
    private lateinit var speedPanel: View
    private lateinit var speedSeek: SeekBar
    private lateinit var tvSpeedValue: TextView
    private lateinit var morePanel: View
    private lateinit var bFavorite: TextView
    private lateinit var bAbRepeat: TextView
    private lateinit var bNight: TextView
    private lateinit var bMirror: TextView
    private lateinit var bTimer: TextView
    private lateinit var bLoop: TextView

    // state
    private var locked = false
    private var muted = false
    private var dragging = false
    private var nightOn = false
    private var mirrorOn = false
    private var abA = -1L
    private var abB = -1L
    private var speedStep = 15 // 15 -> 1.00x, see speedFromStep()
    private var resizeIndex = 0
    private var sleepMinutes = 0
    private var cutStart = -1L
    private var cutEnd = -1L
    private var equalizer: Equalizer? = null
    private var transformer: Transformer? = null

    // gestures
    private var gestureMode = MODE_NONE
    private var gestureStartPos = 0L
    private var gestureStartBrightness = 0.5f
    private var gestureStartVolume = 0
    private var gestureSeekTarget = -1L

    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop")

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 200)
        }
    }
    private val hideRunnable = Runnable {
        if (::player.isInitialized && player.isPlaying && !panelVisible() && !dragging) hideControls()
    }
    private val osdHideRunnable = Runnable { tvOsd.visibility = View.GONE }
    private val unlockHideRunnable = Runnable { btnUnlock.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        player.pause()
        sleepMinutes = 0
        updateMoreLabels()
        toast("Sleep timer: paused")
    }

    private val gestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = MODE_NONE
                gestureSeekTarget = -1L
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    showUnlockButton()
                } else if (panelVisible()) {
                    hidePanels()
                } else {
                    toggleControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < root.width / 2f) seekBy(-10_000) else seekBy(10_000)
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (locked || e1 == null) return false
                if (gestureMode == MODE_NONE) {
                    gestureMode = when {
                        abs(e2.x - e1.x) > abs(e2.y - e1.y) -> MODE_SEEK
                        e1.x < root.width / 2f -> MODE_BRIGHTNESS
                        else -> MODE_VOLUME
                    }
                    gestureStartPos = player.currentPosition
                    gestureStartBrightness = currentBrightness()
                    gestureStartVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                }
                val fractionY = (e1.y - e2.y) / root.height.toFloat()
                when (gestureMode) {
                    MODE_SEEK -> {
                        val dur = player.duration
                        if (dur > 0) {
                            val delta = ((e2.x - e1.x) / root.width.toFloat() * 120_000f).toLong()
                            gestureSeekTarget = (gestureStartPos + delta).coerceIn(0L, dur)
                            val sign = if (delta >= 0) "+" else "-"
                            showOsd(formatTime(gestureSeekTarget) + "  (" + sign + formatTime(abs(delta)) + ")")
                        }
                    }
                    MODE_BRIGHTNESS -> {
                        val b = (gestureStartBrightness + fractionY * 1.2f).coerceIn(0.02f, 1f)
                        setBrightness(b)
                        showOsd("Brightness " + (b * 100).roundToInt() + "%")
                    }
                    MODE_VOLUME -> {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (gestureStartVolume + fractionY * 1.2f * max).roundToInt().coerceIn(0, max)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showOsd("Volume " + (if (max > 0) v * 100 / max else 0) + "%")
                    }
                }
                return true
            }
        })
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_player)

        bindViews()
        if (!setupPlayer()) {
            toast("Nothing to play")
            finish()
            return
        }
        wireControls()
        hideSystemBars()
        applySpeedStep(speedStep)
        updateTitle()
        updatePlayIcon()
        updateMoreLabels()
        handler.post(ticker)
        showControls()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        if (::player.isInitialized) {
            saveResume()
            if (!isInPictureInPictureMode) player.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            equalizer?.release()
        } catch (e: Exception) {
            // ignore
        }
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        if (::player.isInitialized) {
            saveResume()
            player.release()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        when {
            locked -> {
                showUnlockButton()
                toast("Screen is locked")
            }
            panelVisible() -> hidePanels()
            else -> super.onBackPressed()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            hidePanels()
            controls.visibility = View.GONE
            btnUnlock.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------------ setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        playerView = findViewById(R.id.playerView)
        nightOverlay = findViewById(R.id.nightOverlay)
        controls = findViewById(R.id.controls)
        btnUnlock = findViewById(R.id.btnUnlock)
        tvOsd = findViewById(R.id.tvOsd)
        tvTitle = findViewById(R.id.tvTitle)
        tvPosition = findViewById(R.id.tvPosition)
        tvRemaining = findViewById(R.id.tvRemaining)
        seekBar = findViewById(R.id.seekBar)
        btnPlay = findViewById(R.id.btnPlay)
        btnMute = findViewById(R.id.btnMute)
        btnLock = findViewById(R.id.btnLock)
        btnSpeed = findViewById(R.id.btnSpeed)
        speedPanel = findViewById(R.id.speedPanel)
        speedSeek = findViewById(R.id.speedSeek)
        tvSpeedValue = findViewById(R.id.tvSpeedValue)
        morePanel = findViewById(R.id.morePanel)
        bFavorite = findViewById(R.id.bFavorite)
        bAbRepeat = findViewById(R.id.bAbRepeat)
        bNight = findViewById(R.id.bNight)
        bMirror = findViewById(R.id.bMirror)
        bTimer = findViewById(R.id.bTimer)
        bLoop = findViewById(R.id.bLoop)
    }

    private fun setupPlayer(): Boolean {
        val list = ArrayList<VideoItem>()
        var index = 0
        val data = intent?.data
        if (Intent.ACTION_VIEW == intent?.action && data != null) {
            list.add(VideoItem(data, queryName(this, data), 0L, 0L))
        } else {
            list.addAll(PlaylistHolder.items)
            index = PlaylistHolder.index
        }
        if (list.isEmpty()) return false
        index = index.coerceIn(0, list.size - 1)

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(androidx.media3.common.AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        playerView.player = player

        val mediaItems = list.map { v ->
            MediaItem.Builder()
                .setUri(v.uri)
                .setMediaId(v.uri.toString())
                .setMediaMetadata(MediaMetadata.Builder().setTitle(v.name).build())
                .build()
        }
        val resume = Prefs.resume(this, list[index].uri.toString())
        player.setMediaItems(mediaItems, index, if (resume > 0) resume else C.TIME_UNSET)

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayIcon()
                if (isPlaying) scheduleHide()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updatePlayIcon()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                abA = -1L
                abB = -1L
                cutStart = -1L
                cutEnd = -1L
                updateTitle()
                updateMoreLabels()
            }

            override fun onPlayerError(error: PlaybackException) {
                toast("Cannot play this video (" + error.errorCodeName + ")")
            }
        })

        player.prepare()
        player.playWhenReady = true
        return true
    }

    private fun wireControls() {
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnSubs).setOnClickListener { showTrackDialog(C.TRACK_TYPE_TEXT) }
        findViewById<ImageButton>(R.id.btnPlaylist).setOnClickListener { showPlaylistDialog() }
        findViewById<ImageButton>(R.id.btnMore).setOnClickListener { showPanel(morePanel) }

        btnPlay.setOnClickListener {
            if (player.isPlaying) {
                player.pause()
            } else {
                if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition(0)
                player.play()
            }
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0)
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else toast("Last video")
            scheduleHide()
        }

        btnMute.setOnClickListener {
            muted = !muted
            player.volume = if (muted) 0f else 1f
            btnMute.setImageResource(if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_on)
            scheduleHide()
        }
        btnLock.setOnClickListener {
            locked = true
            hidePanels()
            controls.visibility = View.GONE
            showUnlockButton()
            toast("Screen locked")
        }
        btnUnlock.setOnClickListener {
            locked = false
            btnUnlock.visibility = View.GONE
            showControls()
        }
        findViewById<ImageButton>(R.id.btnRotate).setOnClickListener {
            requestedOrientation =
                if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) {
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
        }
        findViewById<ImageButton>(R.id.btnAspect).setOnClickListener {
            resizeIndex = (resizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIndex]
            showOsd(resizeNames[resizeIndex])
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnPip).setOnClickListener { enterPip() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tvPosition.text = formatTime(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                player.seekTo((sb?.progress ?: 0).toLong())
                scheduleHide()
            }
        })

        // speed
        btnSpeed.setOnClickListener { showPanel(speedPanel) }
        findViewById<TextView>(R.id.btnSpeedMinus).setOnClickListener { applySpeedStep(speedStep - 1) }
        findViewById<TextView>(R.id.btnSpeedPlus).setOnClickListener { applySpeedStep(speedStep + 1) }
        findViewById<TextView>(R.id.btnSpeedReset).setOnClickListener { applySpeedStep(15) }
        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) applySpeedStep(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // more panel
        findViewById<TextView>(R.id.bAudio).setOnClickListener {
            hidePanels()
            showTrackDialog(C.TRACK_TYPE_AUDIO)
        }
        findViewById<TextView>(R.id.bEqualizer).setOnClickListener {
            hidePanels()
            showEqualizerDialog()
        }
        findViewById<TextView>(R.id.bShare).setOnClickListener {
            hidePanels()
            shareCurrent()
        }
        findViewById<TextView>(R.id.bCut).setOnClickListener {
            hidePanels()
            showCutDialog()
        }
        bFavorite.setOnClickListener {
            val id = player.currentMediaItem?.mediaId ?: return@setOnClickListener
            val added = Prefs.toggleFavorite(this, id)
            toast(if (added) "Added to favorites" else "Removed from favorites")
            updateMoreLabels()
        }
        findViewById<TextView>(R.id.bBookmark).setOnClickListener {
            hidePanels()
            showBookmarkDialog()
        }
        bAbRepeat.setOnClickListener {
            when {
                abA < 0 -> {
                    abA = player.currentPosition
                    toast("A set at " + formatTime(abA) + ". Tap again to set B.")
                }
                abB < 0 -> {
                    val p = player.currentPosition
                    if (p > abA + 500) {
                        abB = p
                        toast("Repeating A to B")
                    } else {
                        toast("B must come after A")
                    }
                }
                else -> {
                    abA = -1L
                    abB = -1L
                    toast("AB repeat off")
                }
            }
            updateMoreLabels()
        }
        bNight.setOnClickListener {
            nightOn = !nightOn
            nightOverlay.visibility = if (nightOn) View.VISIBLE else View.GONE
            updateMoreLabels()
        }
        bMirror.setOnClickListener {
            mirrorOn = !mirrorOn
            playerView.videoSurfaceView?.scaleX = if (mirrorOn) -1f else 1f
            updateMoreLabels()
        }
        bTimer.setOnClickListener {
            hidePanels()
            showTimerDialog()
        }
        bLoop.setOnClickListener {
            hidePanels()
            showLoopDialog()
        }

        // touch gestures on the whole screen (buttons consume their own touches)
        root.setOnTouchListener { _, ev ->
            gestureDetector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == MODE_SEEK && gestureSeekTarget >= 0) {
                    player.seekTo(gestureSeekTarget)
                }
                gestureMode = MODE_NONE
                gestureSeekTarget = -1L
            }
            true
        }
    }

    // ------------------------------------------------------------------ UI helpers

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun panelVisible(): Boolean =
        speedPanel.visibility == View.VISIBLE || morePanel.visibility == View.VISIBLE

    private fun hidePanels() {
        speedPanel.visibility = View.GONE
        morePanel.visibility = View.GONE
    }

    private fun showPanel(panel: View) {
        hidePanels()
        updateMoreLabels()
        panel.visibility = View.VISIBLE
        handler.removeCallbacks(hideRunnable)
    }

    private fun showControls() {
        if (locked) return
        controls.visibility = View.VISIBLE
        updateProgress()
        scheduleHide()
    }

    private fun hideControls() {
        controls.visibility = View.GONE
    }

    private fun toggleControls() {
        if (controls.visibility == View.VISIBLE) hideControls() else showControls()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    private fun showUnlockButton() {
        btnUnlock.visibility = View.VISIBLE
        handler.removeCallbacks(unlockHideRunnable)
        handler.postDelayed(unlockHideRunnable, 2500)
    }

    private fun showOsd(text: String) {
        tvOsd.text = text
        tvOsd.visibility = View.VISIBLE
        handler.removeCallbacks(osdHideRunnable)
        handler.postDelayed(osdHideRunnable, 900)
    }

    private fun updateTitle() {
        val t = player.currentMediaItem?.mediaMetadata?.title
        tvTitle.text = t ?: ""
    }

    private fun updatePlayIcon() {
        val showPause = player.playWhenReady && player.playbackState != Player.STATE_ENDED
        btnPlay.setImageResource(if (showPause) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateProgress() {
        if (!::player.isInitialized) return
        val dur = player.duration
        val total = if (dur == C.TIME_UNSET || dur < 0) 0L else dur
        val pos = player.currentPosition
        if (!dragging) {
            seekBar.max = total.toInt()
            seekBar.progress = pos.toInt()
            seekBar.secondaryProgress = player.bufferedPosition.toInt()
            tvPosition.text = formatTime(pos)
        }
        tvRemaining.text = "-" + formatTime(total - pos)
        if (abA >= 0 && abB >= 0 && pos >= abB) {
            player.seekTo(abA)
        }
    }

    private fun updateMoreLabels() {
        val id = player.currentMediaItem?.mediaId
        val fav = id != null && Prefs.isFavorite(this, id)
        bFavorite.text = if (fav) "★ Favorite" else "☆ Favorite"
        bAbRepeat.text = when {
            abA < 0 -> "AB Repeat"
            abB < 0 -> "AB Repeat\nA " + formatTime(abA)
            else -> "AB Repeat\n" + formatTime(abA) + " - " + formatTime(abB)
        }
        bNight.text = if (nightOn) "Night mode\nON" else "Night mode"
        bMirror.text = if (mirrorOn) "Mirror mode\nON" else "Mirror mode"
        bTimer.text = if (sleepMinutes > 0) "Timer\n$sleepMinutes min" else "Timer"
        val loopName = when (player.repeatMode) {
            Player.REPEAT_MODE_ONE -> "One"
            Player.REPEAT_MODE_ALL -> "All"
            else -> "Off"
        }
        bLoop.text = "Loop\n$loopName"
    }

    // ------------------------------------------------------------------ playback helpers

    private fun seekBy(deltaMs: Long) {
        val dur = player.duration
        val max = if (dur == C.TIME_UNSET || dur < 0) Long.MAX_VALUE else dur
        player.seekTo((player.currentPosition + deltaMs).coerceIn(0L, max))
        showOsd(if (deltaMs > 0) "+10s" else "-10s")
    }

    private fun speedFromStep(step: Int): Float = (25 + step * 5) / 100f

    private fun applySpeedStep(step: Int) {
        speedStep = step.coerceIn(0, 75)
        val speed = speedFromStep(speedStep)
        player.setPlaybackSpeed(speed)
        tvSpeedValue.text = String.format(Locale.US, "%.2f X", speed)
        btnSpeed.text = String.format(Locale.US, "Speed %.2fx", speed)
        if (speedSeek.progress != speedStep) speedSeek.progress = speedStep
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(value: Float) {
        val lp = window.attributes
        lp.screenBrightness = value
        window.attributes = lp
    }

    private fun saveResume() {
        val item = player.currentMediaItem ?: return
        val dur = player.duration
        val pos = player.currentPosition
        val nearEnd = dur > 0 && pos > dur - 5000
        Prefs.setResume(this, item.mediaId, if (nearEnd) 0L else pos)
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            val size = player.videoSize
            val w = if (size.width > 0) size.width else 16
            val h = if (size.height > 0) size.height else 9
            val ratio = w.toFloat() / h.toFloat()
            val rational = when {
                ratio > 2.39f -> Rational(239, 100)
                ratio < 0.5f -> Rational(1, 2)
                else -> Rational(w, h)
            }
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(rational).build()
                )
            } catch (e: Exception) {
                toast("Picture-in-picture is not available")
            }
        } else {
            toast("Picture-in-picture is not supported on this phone")
        }
    }

    // ------------------------------------------------------------------ dialogs

    private fun trackLabel(f: Format, number: Int, isAudio: Boolean): String {
        val lang = f.language
        val langName = if (lang != null && lang != "und") {
            Locale(lang).displayLanguage.takeIf { it.isNotBlank() && !it.equals(lang, ignoreCase = true) }
        } else {
            null
        }
        val sb = StringBuilder()
        sb.append(f.label ?: langName ?: ("Track " + (number + 1)))
        if (isAudio) {
            val codec = f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            if (!codec.isNullOrBlank()) sb.append(" · ").append(codec)
            if (f.channelCount > 0) sb.append(" · ").append(f.channelCount).append("ch")
        }
        return sb.toString()
    }

    private fun showTrackDialog(type: Int) {
        val isText = type == C.TRACK_TYPE_TEXT
        val entries = ArrayList<TrackEntry>()
        for (g in player.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(
                    TrackEntry(g, i, trackLabel(g.getTrackFormat(i), entries.size, !isText), g.isTrackSelected(i))
                )
            }
        }
        if (entries.isEmpty() && !isText) {
            toast("No audio tracks found")
            return
        }

        val labels = ArrayList<String>()
        if (isText) labels.add("Off")
        val offset = labels.size
        var checked = -1
        for ((n, e) in entries.withIndex()) {
            labels.add(e.label)
            if (e.selected) checked = n + offset
        }
        if (isText) {
            val disabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
            if (disabled || checked < 0) checked = 0
            labels.add("Load subtitle file…")
        }

        AlertDialog.Builder(this)
            .setTitle(if (isText) "Subtitles" else "Audio track")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { dialog, which ->
                dialog.dismiss()
                if (isText && which == 0) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                } else if (isText && which == labels.size - 1) {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "*/*"
                    startActivityForResult(i, REQ_SUBTITLE)
                } else {
                    val e = entries[which - offset]
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(type, false)
                        .setOverrideForType(TrackSelectionOverride(e.group.mediaTrackGroup, e.index))
                        .build()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SUBTITLE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // fine, we only need the file for this session
            }
            addExternalSubtitle(uri)
        }
    }

    private fun addExternalSubtitle(uri: Uri) {
        val current = player.currentMediaItem ?: return
        val name = queryName(this, uri).lowercase(Locale.ROOT)
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val subtitle = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val index = player.currentMediaItemIndex
        val position = player.currentPosition
        val updated = current.buildUpon().setSubtitleConfigurations(listOf(subtitle)).build()
        player.replaceMediaItem(index, updated)
        player.seekTo(index, position)
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        toast("Subtitle loaded")
    }

    private fun showPlaylistDialog() {
        val count = player.mediaItemCount
        val titles = Array(count) { i ->
            (player.getMediaItemAt(i).mediaMetadata.title ?: "Video ${i + 1}").toString()
        }
        AlertDialog.Builder(this)
            .setTitle("Playlist")
            .setSingleChoiceItems(titles, player.currentMediaItemIndex) { dialog, which ->
                dialog.dismiss()
                player.seekTo(which, 0L)
                player.play()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showTimerDialog() {
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val minutes = intArrayOf(0, 15, 30, 45, 60, 90)
        val checked = minutes.indexOf(sleepMinutes).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                handler.removeCallbacks(sleepRunnable)
                sleepMinutes = minutes[which]
                if (sleepMinutes > 0) {
                    handler.postDelayed(sleepRunnable, sleepMinutes * 60_000L)
                    toast("Video will pause in $sleepMinutes minutes")
                } else {
                    toast("Timer off")
                }
                updateMoreLabels()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showLoopDialog() {
        val labels = arrayOf("Off", "Loop this video", "Loop all videos")
        val modes = intArrayOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ONE, Player.REPEAT_MODE_ALL)
        val checked = modes.indexOf(player.repeatMode).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Loop")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                player.repeatMode = modes[which]
                updateMoreLabels()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showBookmarkDialog() {
        val id = player.currentMediaItem?.mediaId ?: return
        val marks = Prefs.bookmarks(this, id)
        val now = player.currentPosition
        val labels = ArrayList<String>()
        labels.add("+ Add bookmark at " + formatTime(now))
        for (m in marks) labels.add(formatTime(m))
        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) {
                    Prefs.addBookmark(this, id, now)
                    toast("Bookmark added")
                } else {
                    player.seekTo(marks[which - 1])
                }
            }
            .setNeutralButton("Clear all") { _, _ ->
                Prefs.clearBookmarks(this, id)
                toast("Bookmarks cleared")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun ensureEqualizer(): Equalizer? {
        if (equalizer != null) return equalizer
        return try {
            val eq = Equalizer(0, player.audioSessionId)
            equalizer = eq
            eq
        } catch (e: Exception) {
            null
        }
    }

    private fun showEqualizerDialog() {
        val eq = ensureEqualizer()
        if (eq == null) {
            toast("Equalizer is not available on this phone")
            return
        }
        val range = eq.bandLevelRange
        val lo = range[0].toInt()
        val hi = range[1].toInt()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))

        val toggle = Switch(this)
        toggle.text = "Enable equalizer"
        toggle.isChecked = eq.enabled
        toggle.setOnCheckedChangeListener { _, checked -> eq.enabled = checked }
        box.addView(toggle)

        for (b in 0 until eq.numberOfBands.toInt()) {
            val band = b.toShort()
            val label = TextView(this)
            label.text = (eq.getCenterFreq(band) / 1000).toString() + " Hz"
            label.setTextColor(Color.WHITE)
            label.setPadding(0, dp(12), 0, 0)
            box.addView(label)

            val bar = SeekBar(this)
            bar.max = hi - lo
            bar.progress = eq.getBandLevel(band).toInt() - lo
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) eq.setBandLevel(band, (progress + lo).toShort())
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            box.addView(bar)
        }

        AlertDialog.Builder(this)
            .setTitle("Equalizer")
            .setView(box)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun shareCurrent() {
        val uri = player.currentMediaItem?.localConfiguration?.uri ?: return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "video/*"
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "Share video"))
    }

    // ------------------------------------------------------------------ cut (trim) a clip

    private fun showCutDialog() {
        val info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.setPadding(0, 0, 0, dp(12))

        fun refresh() {
            val s = if (cutStart >= 0) formatTime(cutStart) else "--:--"
            val e = if (cutEnd >= 0) formatTime(cutEnd) else "--:--"
            info.text = "Start: $s      End: $e"
        }
        refresh()

        val btnStart = TextView(this)
        btnStart.text = "Set start = current position"
        btnStart.setTextColor(Color.WHITE)
        btnStart.setBackgroundResource(R.drawable.bg_chip)
        btnStart.setPadding(dp(14), dp(12), dp(14), dp(12))
        btnStart.setOnClickListener {
            cutStart = player.currentPosition
            refresh()
        }

        val btnEnd = TextView(this)
        btnEnd.text = "Set end = current position"
        btnEnd.setTextColor(Color.WHITE)
        btnEnd.setBackgroundResource(R.drawable.bg_chip)
        btnEnd.setPadding(dp(14), dp(12), dp(14), dp(12))
        btnEnd.setOnClickListener {
            cutEnd = player.currentPosition
            refresh()
        }

        val gap = dp(8)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        box.addView(info)
        box.addView(btnStart)
        val lpEnd = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lpEnd.topMargin = gap
        box.addView(btnEnd, lpEnd)

        AlertDialog.Builder(this)
            .setTitle("Cut a clip")
            .setView(box)
            .setPositiveButton("Save clip") { _, _ -> startCut() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun startCut() {
        if (cutStart < 0 || cutEnd <= cutStart) {
            toast("Set a start and an end first (end must be after start)")
            return
        }
        val sourceUri = player.currentMediaItem?.localConfiguration?.uri ?: return
        val clipped = MediaItem.Builder()
            .setUri(sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(cutStart)
                    .setEndPositionMs(cutEnd)
                    .build()
            )
            .build()
        val edited = EditedMediaItem.Builder(clipped).build()
        val outFile = File(cacheDir, "clip_" + System.currentTimeMillis() + ".mp4")

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    saveClip(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    toast("Could not cut this video: " + exportException.errorCodeName)
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        toast("Saving clip, please wait…")
    }

    private fun saveClip(file: File) {
        Thread {
            var message = ""
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues()
                    values.put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoPlayer")
                    values.put(MediaStore.Video.Media.IS_PENDING, 1)
                    val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (dest == null) {
                        message = "Could not create the clip file"
                    } else {
                        contentResolver.openOutputStream(dest)?.use { out ->
                            file.inputStream().use { it.copyTo(out) }
                        }
                        val done = ContentValues()
                        done.put(MediaStore.Video.Media.IS_PENDING, 0)
                        contentResolver.update(dest, done, null, null)
                        message = "Clip saved in Movies/VideoPlayer"
                    }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                    if (dir == null) {
                        message = "No storage available"
                    } else {
                        val target = File(dir, file.name)
                        file.copyTo(target, overwrite = true)
                        message = "Clip saved: " + target.absolutePath
                    }
                }
                file.delete()
            } catch (e: Exception) {
                message = "Could not save the clip: " + e.message
            }
            runOnUiThread { toast(message) }
        }.start()
    }
}
