package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.format.DateFormat
import android.util.Rational
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private class TrackEntry(
    val group: Tracks.Group,
    val index: Int,
    val label: String,
    val selected: Boolean
)

class PlayerActivity : Activity() {

    companion object {
        private const val REQ_SUBTITLE = 101
        private const val HIDE_DELAY_MS = 4000L
        private const val MODE_NONE = 0
        private const val MODE_SEEK = 1
        private const val MODE_BRIGHTNESS = 2
        private const val MODE_VOLUME = 3

        private const val LOOP_OFF = 0   // stop after this video
        private const val LOOP_ONE = 1   // repeat this video
        private const val LOOP_NEXT = 2  // play the following videos, stop after the last
        private const val LOOP_ALL = 3   // repeat the whole list
    }

    private lateinit var player: ExoPlayer
    private lateinit var actions: MediaActions
    private val handler = Handler(Looper.getMainLooper())
    private val items = ArrayList<VideoItem>()

    // views
    private lateinit var root: View
    private lateinit var playerView: PlayerView
    private lateinit var nightOverlay: View
    private lateinit var controls: View
    private lateinit var btnUnlock: ImageButton
    private lateinit var tvOsd: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvClock: TextView
    private lateinit var tvBattery: TextView
    private lateinit var miniStatus: TextView
    private lateinit var tvPosition: TextView
    private lateinit var tvRemaining: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var btnMute: ImageButton
    private lateinit var btnLock: ImageButton
    private lateinit var btnSpeed: TextView
    private lateinit var speedPanel: View
    private lateinit var speedSeek: SeekBar
    private lateinit var tvSpeedValue: TextView
    private lateinit var morePanel: View
    private lateinit var bFavorite: TextView
    private lateinit var bAbRepeat: TextView
    private lateinit var bNight: TextView
    private lateinit var bMirror: TextView
    private lateinit var bTimer: TextView
    private lateinit var bLoop: TextView
    private lateinit var bBoost: TextView
    private lateinit var bStatus: TextView

    // state
    private var locked = false
    private var muted = false
    private var dragging = false
    private var nightOn = false
    private var mirrorOn = false
    private var inPip = false
    private var navForced = false
    private var userRotated = false
    private var pinched = false
    private var tapConsumed = false
    private var abA = -1L
    private var abB = -1L
    private var speedStep = 15 // 15 -> 1.00x, see speedFromStep()
    private var resizeIndex = 0
    private var sleepMinutes = 0
    private var cutStart = -1L
    private var cutEnd = -1L
    private var loopMode = LOOP_OFF
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var pBrightness = 0
    private var pContrast = 100
    private var pSaturation = 100
    private var boostDb = 0
    private var subSizeIndex = 1
    private var errorRetries = 0
    private var batteryPct = -1
    private var charging = false
    private var lastClock = ""
    private var equalizer: Equalizer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var transformer: Transformer? = null

    // gestures
    private var gestureMode = MODE_NONE
    private var gestureStartPos = 0L
    private var gestureStartBrightness = 0.5f
    private var gestureStartVolume = 0
    private var gestureSeekTarget = -1L

    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop")
    private val subSizes = floatArrayOf(0.04f, 0.0533f, 0.07f, 0.09f)
    private val subSizeNames = arrayOf("Small", "Medium", "Large", "Extra large")

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            updateClock()
            handler.postDelayed(this, 200)
        }
    }
    private val hideRunnable = Runnable {
        if (::player.isInitialized && player.isPlaying && !panelVisible() && !dragging) hideControls()
    }
    private val osdHideRunnable = Runnable { tvOsd.visibility = View.GONE }
    private val unlockHideRunnable = Runnable { btnUnlock.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        player.pause()
        sleepMinutes = 0
        updateMoreLabels()
        toast("Sleep timer: paused")
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            batteryPct = if (level >= 0 && scale > 0) level * 100 / scale else -1
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            updateStatusText()
        }
    }

    private val fileListener = object : MediaActions.Listener {
        override fun onDeleted(item: VideoItem) {
            removeFromPlaylist(item)
        }

        override fun onRenamed(old: VideoItem, updated: VideoItem) {
            handleRenamed(old, updated)
        }

        override fun onHiddenChanged(item: VideoItem) {
            removeFromPlaylist(item)
        }

        override fun onFavoriteChanged(item: VideoItem) {
            updateMoreLabels()
        }
    }

    private val scaleDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (locked) return false
                pinched = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (locked) return false
                setZoom(zoom * detector.scaleFactor)
                showOsd("Zoom " + (zoom * 100).roundToInt() + "%")
                return true
            }
        })
    }

    private val gestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = MODE_NONE
                gestureSeekTarget = -1L
                pinched = false
                return true
            }

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                tapConsumed = false
                if (locked) return false
                if (inCenter(e)) {
                    // a tap in the middle of the screen pauses / resumes the video
                    tapConsumed = true
                    if (panelVisible()) {
                        hidePanels()
                    } else {
                        togglePlay()
                        showOsd(if (player.playWhenReady) "Playing" else "Paused")
                    }
                    return true
                }
                return false
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (tapConsumed) {
                    tapConsumed = false
                    return true
                }
                if (locked) {
                    showUnlockButton()
                } else if (panelVisible()) {
                    hidePanels()
                } else {
                    toggleControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked || inCenter(e)) return true
                if (e.x < root.width / 2f) seekBy(-10_000) else seekBy(10_000)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked || pinched || panelVisible() || zoom > 1f || gestureMode != MODE_NONE) return
                showFileMenu()
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (locked || e1 == null) return false
                if (pinched || scaleDetector.isInProgress || e2.pointerCount > 1) return false
                if (zoom > 1f) {
                    // zoomed in: dragging moves the picture around
                    panX -= distanceX
                    panY -= distanceY
                    applyZoom()
                    return true
                }
                if (gestureMode == MODE_NONE) {
                    gestureMode = when {
                        abs(e2.x - e1.x) > abs(e2.y - e1.y) -> MODE_SEEK
                        e1.x < root.width / 2f -> MODE_BRIGHTNESS
                        else -> MODE_VOLUME
                    }
                    gestureStartPos = player.currentPosition
                    gestureStartBrightness = currentBrightness()
                    gestureStartVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                }
                val fractionY = (e1.y - e2.y) / root.height.toFloat()
                when (gestureMode) {
                    MODE_SEEK -> {
                        val dur = player.duration
                        if (dur > 0) {
                            val delta = ((e2.x - e1.x) / root.width.toFloat() * 120_000f).toLong()
                            gestureSeekTarget = (gestureStartPos + delta).coerceIn(0L, dur)
                            val sign = if (delta >= 0) "+" else "-"
                            showOsd(formatTime(gestureSeekTarget) + "  (" + sign + formatTime(abs(delta)) + ")")
                        }
                    }
                    MODE_BRIGHTNESS -> {
                        val b = (gestureStartBrightness + fractionY * 1.2f).coerceIn(0.02f, 1f)
                        setBrightness(b)
                        showOsd("Brightness " + (b * 100).roundToInt() + "%")
                    }
                    MODE_VOLUME -> {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (gestureStartVolume + fractionY * 1.2f * max).roundToInt().coerceIn(0, max)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showOsd("Volume " + (if (max > 0) v * 100 / max else 0) + "%")
                    }
                }
                return true
            }
        })
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.argb(110, 0, 0, 0)
        window.navigationBarColor = Color.argb(110, 0, 0, 0)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_player)

        actions = MediaActions(this)
        loadSettings()
        bindViews()
        installInsets()
        adaptLayout()
        if (!setupPlayer()) {
            Toast.makeText(this, "Nothing to play", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        wireControls()
        applySpeedStep(speedStep)
        applyLoopMode()
        applySubtitleStyle()
        applyPicture()
        applyBoost()
        playerView.defaultArtwork = getDrawable(R.drawable.ic_audio)
        updateTitle()
        updatePlayIcon()
        updateMoreLabels()
        registerBattery()
        handler.post(ticker)
        showControls()
    }

    private fun loadSettings() {
        loopMode = Prefs.getInt(this, "loop_mode", LOOP_OFF)
        pBrightness = Prefs.getInt(this, "pic_brightness", 0)
        pContrast = Prefs.getInt(this, "pic_contrast", 100)
        pSaturation = Prefs.getInt(this, "pic_saturation", 100)
        subSizeIndex = Prefs.getInt(this, "sub_size", 1).coerceIn(0, subSizes.size - 1)
    }

    private fun installInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            controls.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            val lp = miniStatus.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = bars.top + dp(8)
            lp.marginEnd = bars.right + dp(12)
            miniStatus.layoutParams = lp
            insets
        }
    }

    private fun registerBattery() {
        try {
            val sticky = ContextCompat.registerReceiver(
                this,
                batteryReceiver,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            if (sticky != null) batteryReceiver.onReceive(this, sticky)
        } catch (e: Exception) {
            // battery level just will not be shown
        }
        updateClock()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applySystemBars()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::root.isInitialized) {
            setZoom(1f)
            adaptLayout()
        }
    }

    /** Sizes buttons and panels from the real screen size so everything fits on small and large phones. */
    private fun adaptLayout() {
        val cfg = resources.configuration
        val compactHeight = cfg.screenHeightDp < 420
        val compactWidth = cfg.screenWidthDp < 360
        val side = if (compactHeight) 38 else 44
        val sideIds = intArrayOf(
            R.id.btnMute, R.id.btnLock, R.id.btnShot,
            R.id.btnRotate, R.id.btnAspect, R.id.btnPip, R.id.btnNav
        )
        for (id in sideIds) setSize(findViewById(id), side, side)

        val bar = if (compactWidth) 38 else 44
        setSize(findViewById(R.id.btnPrev), bar, bar)
        setSize(findViewById(R.id.btnNext), bar, bar)
        for (id in intArrayOf(R.id.btnRewind, R.id.btnForward)) {
            val b = findViewById<View>(id)
            setSize(b, bar, bar)
            setSize(b.parent as View, bar, bar)
        }
        val play = if (compactWidth || compactHeight) 48 else 56
        setSize(findViewById(R.id.btnPlay), play, play)

        morePanel.layoutParams = morePanel.layoutParams.also {
            it.width = dp(minOf(340, cfg.screenWidthDp - 24))
        }
        speedPanel.layoutParams = (speedPanel.layoutParams as FrameLayout.LayoutParams).also {
            it.width = dp(minOf(320, cfg.screenWidthDp - 24))
            it.bottomMargin = dp(if (compactHeight) 96 else 130)
        }
    }

    private fun setSize(v: View, wDp: Int, hDp: Int) {
        val lp = v.layoutParams ?: return
        lp.width = dp(wDp)
        lp.height = dp(hDp)
        v.layoutParams = lp
    }

    override fun onStop() {
        super.onStop()
        if (::player.isInitialized) {
            saveResume()
            if (!isInPictureInPictureMode) player.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            // not registered
        }
        try {
            equalizer?.release()
        } catch (e: Exception) {
            // ignore
        }
        try {
            enhancer?.release()
        } catch (e: Exception) {
            // ignore
        }
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        if (::player.isInitialized) {
            saveResume()
            player.release()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        when {
            locked -> {
                showUnlockButton()
                toast("Screen is locked")
            }
            panelVisible() -> hidePanels()
            else -> super.onBackPressed()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            hidePanels()
            controls.visibility = View.GONE
            btnUnlock.visibility = View.GONE
            updateMiniVisibility()
        } else {
            showControls()
        }
    }

    // ------------------------------------------------------------------ setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        playerView = findViewById(R.id.playerView)
        nightOverlay = findViewById(R.id.nightOverlay)
        controls = findViewById(R.id.controls)
        btnUnlock = findViewById(R.id.btnUnlock)
        tvOsd = findViewById(R.id.tvOsd)
        tvTitle = findViewById(R.id.tvTitle)
        tvClock = findViewById(R.id.tvClock)
        tvBattery = findViewById(R.id.tvBattery)
        miniStatus = findViewById(R.id.miniStatus)
        tvPosition = findViewById(R.id.tvPosition)
        tvRemaining = findViewById(R.id.tvRemaining)
        seekBar = findViewById(R.id.seekBar)
        btnPlay = findViewById(R.id.btnPlay)
        btnMute = findViewById(R.id.btnMute)
        btnLock = findViewById(R.id.btnLock)
        btnSpeed = findViewById(R.id.btnSpeed)
        speedPanel = findViewById(R.id.speedPanel)
        speedSeek = findViewById(R.id.speedSeek)
        tvSpeedValue = findViewById(R.id.tvSpeedValue)
        morePanel = findViewById(R.id.morePanel)
        bFavorite = findViewById(R.id.bFavorite)
        bAbRepeat = findViewById(R.id.bAbRepeat)
        bNight = findViewById(R.id.bNight)
        bMirror = findViewById(R.id.bMirror)
        bTimer = findViewById(R.id.bTimer)
        bLoop = findViewById(R.id.bLoop)
        bBoost = findViewById(R.id.bBoost)
        bStatus = findViewById(R.id.bStatus)
    }

    private fun buildMediaItem(v: VideoItem): MediaItem =
        MediaItem.Builder()
            .setUri(v.uri)
            .setMediaId(v.uri.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(v.name).build())
            .build()

    private fun setupPlayer(): Boolean {
        val list = ArrayList<VideoItem>()
        var index = 0
        val data = intent?.data
        if (Intent.ACTION_VIEW == intent?.action && data != null) {
            val n = queryName(this, data)
            list.add(VideoItem(data, n, 0L, 0L, isAudio = isAudioName(n)))
        } else {
            list.addAll(PlaylistHolder.items)
            index = PlaylistHolder.index
        }
        if (list.isEmpty()) return false
        index = index.coerceIn(0, list.size - 1)
        items.clear()
        items.addAll(list)

        // decoder fallback: if the first-choice decoder fails, try another one instead of giving up
        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
        // wider container support: seeking in constant-bitrate audio (mp3, aac, amr...) and more
        val extractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        player = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this, extractors))
            .setAudioAttributes(androidx.media3.common.AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        playerView.player = player

        val mediaItems = list.map { buildMediaItem(it) }
        val resume = Prefs.resume(this, list[index].uri.toString())
        player.setMediaItems(mediaItems, index, if (resume > 0) resume else C.TIME_UNSET)

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayIcon()
                if (isPlaying) scheduleHide()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                updatePlayIcon()
                applySystemBars()
                if (!playWhenReady) showControls() else scheduleHide()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                updatePlayIcon()
                if (playbackState == Player.STATE_READY) errorRetries = 0
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                abA = -1L
                abB = -1L
                cutStart = -1L
                cutEnd = -1L
                errorRetries = 0
                updateTitle()
                updateMoreLabels()
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                autoOrient(videoSize)
            }

            override fun onPlayerError(error: PlaybackException) {
                if (errorRetries < 1) {
                    // one quiet retry (uses the fallback decoder if needed)
                    errorRetries++
                    val pos = player.currentPosition
                    player.prepare()
                    player.seekTo(pos)
                } else {
                    toast("Cannot play this video (" + error.errorCodeName + ")")
                }
            }
        })

        player.prepare()
        player.playWhenReady = true
        return true
    }

    private fun autoOrient(videoSize: VideoSize) {
        if (userRotated || videoSize.width <= 0 || videoSize.height <= 0) return
        val ratio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
        var w = videoSize.width * ratio
        var h = videoSize.height.toFloat()
        if (videoSize.unappliedRotationDegrees == 90 || videoSize.unappliedRotationDegrees == 270) {
            val t = w
            w = h
            h = t
        }
        val target = if (h > w) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        if (requestedOrientation != target) requestedOrientation = target
    }

    private fun wireControls() {
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnSubs).setOnClickListener { showTrackDialog(C.TRACK_TYPE_TEXT) }
        findViewById<ImageButton>(R.id.btnPlaylist).setOnClickListener { showPlaylistDialog() }
        findViewById<ImageButton>(R.id.btnMore).setOnClickListener { showPanel(morePanel) }

        btnPlay.setOnClickListener {
            togglePlay()
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0)
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else toast("Last video")
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnRewind).setOnClickListener {
            seekBy(-10_000)
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener {
            seekBy(10_000)
            scheduleHide()
        }

        btnMute.setOnClickListener {
            muted = !muted
            player.volume = if (muted) 0f else 1f
            btnMute.setImageResource(if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_on)
            scheduleHide()
        }
        btnLock.setOnClickListener {
            locked = true
            hidePanels()
            controls.visibility = View.GONE
            updateMiniVisibility()
            applySystemBars()
            showUnlockButton()
            toast("Screen locked")
        }
        btnUnlock.setOnClickListener {
            locked = false
            btnUnlock.visibility = View.GONE
            showControls()
        }
        findViewById<ImageButton>(R.id.btnShot).setOnClickListener { takeScreenshot() }
        findViewById<ImageButton>(R.id.btnRotate).setOnClickListener {
            userRotated = true
            requestedOrientation =
                if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) {
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
        }
        findViewById<ImageButton>(R.id.btnAspect).setOnClickListener {
            resizeIndex = (resizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIndex]
            showOsd(resizeNames[resizeIndex])
            scheduleHide()
        }
        findViewById<ImageButton>(R.id.btnPip).setOnClickListener { enterPip() }
        findViewById<ImageButton>(R.id.btnNav).setOnClickListener {
            navForced = !navForced
            applySystemBars()
            showOsd(if (navForced) "Navigation buttons on" else "Navigation buttons off")
            scheduleHide()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tvPosition.text = formatTime(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                player.seekTo((sb?.progress ?: 0).toLong())
                scheduleHide()
            }
        })

        // speed
        btnSpeed.setOnClickListener { showPanel(speedPanel) }
        findViewById<TextView>(R.id.btnSpeedMinus).setOnClickListener { applySpeedStep(speedStep - 1) }
        findViewById<TextView>(R.id.btnSpeedPlus).setOnClickListener { applySpeedStep(speedStep + 1) }
        findViewById<TextView>(R.id.btnSpeedReset).setOnClickListener { applySpeedStep(15) }
        val presets = mapOf(
            R.id.sp050 to 5,
            R.id.sp075 to 10,
            R.id.sp100 to 15,
            R.id.sp125 to 20,
            R.id.sp150 to 25,
            R.id.sp200 to 35
        )
        for ((id, step) in presets) {
            findViewById<TextView>(id).setOnClickListener { applySpeedStep(step) }
        }
        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) applySpeedStep(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // more panel
        findViewById<TextView>(R.id.bAudio).setOnClickListener {
            hidePanels()
            showTrackDialog(C.TRACK_TYPE_AUDIO)
        }
        findViewById<TextView>(R.id.bEqualizer).setOnClickListener {
            hidePanels()
            showEqualizerDialog()
        }
        bBoost.setOnClickListener {
            hidePanels()
            showBoostDialog()
        }
        findViewById<TextView>(R.id.bPicture).setOnClickListener {
            hidePanels()
            showPictureDialog()
        }
        findViewById<TextView>(R.id.bSubSize).setOnClickListener {
            hidePanels()
            showSubtitleSizeDialog()
        }
        findViewById<TextView>(R.id.bShot).setOnClickListener {
            hidePanels()
            takeScreenshot()
        }
        findViewById<TextView>(R.id.bShare).setOnClickListener {
            hidePanels()
            currentItem()?.let { actions.share(it) }
        }
        findViewById<TextView>(R.id.bCut).setOnClickListener {
            hidePanels()
            showCutDialog()
        }
        findViewById<TextView>(R.id.bInfo).setOnClickListener {
            hidePanels()
            showInfoDialog()
        }
        findViewById<TextView>(R.id.bFile).setOnClickListener {
            hidePanels()
            showFileMenu()
        }
        bFavorite.setOnClickListener {
            val id = player.currentMediaItem?.mediaId ?: return@setOnClickListener
            val added = Prefs.toggleFavorite(this, id)
            toast(if (added) "Added to favorites" else "Removed from favorites")
            updateMoreLabels()
        }
        findViewById<TextView>(R.id.bBookmark).setOnClickListener {
            hidePanels()
            showBookmarkDialog()
        }
        bAbRepeat.setOnClickListener {
            when {
                abA < 0 -> {
                    abA = player.currentPosition
                    toast("A set at " + formatTime(abA) + ". Tap again to set B.")
                }
                abB < 0 -> {
                    val p = player.currentPosition
                    if (p > abA + 500) {
                        abB = p
                        toast("Repeating A to B")
                    } else {
                        toast("B must come after A")
                    }
                }
                else -> {
                    abA = -1L
                    abB = -1L
                    toast("AB repeat off")
                }
            }
            updateMoreLabels()
        }
        bNight.setOnClickListener {
            nightOn = !nightOn
            nightOverlay.visibility = if (nightOn) View.VISIBLE else View.GONE
            updateMoreLabels()
        }
        bMirror.setOnClickListener {
            mirrorOn = !mirrorOn
            playerView.videoSurfaceView?.scaleX = if (mirrorOn) -1f else 1f
            updateMoreLabels()
        }
        bTimer.setOnClickListener {
            hidePanels()
            showTimerDialog()
        }
        bLoop.setOnClickListener {
            hidePanels()
            showLoopDialog()
        }
        bStatus.setOnClickListener {
            Prefs.putBool(this, "show_status", !Prefs.showStatus(this))
            updateMoreLabels()
            updateMiniVisibility()
        }
        findViewById<TextView>(R.id.bZoom).setOnClickListener {
            setZoom(1f)
            hidePanels()
            showOsd("Zoom 100%")
        }

        // touch gestures on the whole screen (buttons consume their own touches)
        root.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            gestureDetector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gestureMode == MODE_SEEK && gestureSeekTarget >= 0) {
                    player.seekTo(gestureSeekTarget)
                }
                gestureMode = MODE_NONE
                gestureSeekTarget = -1L
            }
            true
        }
    }

    // ------------------------------------------------------------------ UI helpers

    /** Messages are drawn on the video itself with a see-through background instead of a system toast. */
    private fun toast(s: String) {
        showOsd(s, 2200L)
    }

    /** Pause / resume area: a circle of 1 cm radius around the exact middle of the screen. */
    private fun inCenter(e: MotionEvent): Boolean {
        val radius = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_MM, 10f, resources.displayMetrics
        )
        val dx = e.x - root.width / 2f
        val dy = e.y - root.height / 2f
        return dx * dx + dy * dy <= radius * radius
    }

    /**
     * The phone's navigation buttons appear when the player's navigation button is switched on or while the
     * video is paused, and stay hidden otherwise. The status bar is always hidden.
     */
    private fun applySystemBars() {
        val paused = ::player.isInitialized && !player.playWhenReady
        val showNav = !inPip && !locked && (navForced || paused)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.isAppearanceLightStatusBars = false
        c.isAppearanceLightNavigationBars = false
        // the top status bar stays hidden (clock and battery are drawn by the player)
        c.hide(WindowInsetsCompat.Type.statusBars())
        if (showNav) {
            c.show(WindowInsetsCompat.Type.navigationBars())
        } else {
            c.hide(WindowInsetsCompat.Type.navigationBars())
        }
    }

    private fun panelVisible(): Boolean =
        speedPanel.visibility == View.VISIBLE || morePanel.visibility == View.VISIBLE

    private fun hidePanels() {
        speedPanel.visibility = View.GONE
        morePanel.visibility = View.GONE
    }

    private fun showPanel(panel: View) {
        hidePanels()
        updateMoreLabels()
        panel.visibility = View.VISIBLE
        handler.removeCallbacks(hideRunnable)
    }

    private fun showControls() {
        if (locked) return
        controls.visibility = View.VISIBLE
        updateProgress()
        updateMiniVisibility()
        applySystemBars()
        scheduleHide()
    }

    private fun hideControls() {
        controls.visibility = View.GONE
        updateMiniVisibility()
        applySystemBars()
    }

    private fun toggleControls() {
        if (controls.visibility == View.VISIBLE) hideControls() else showControls()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    private fun showUnlockButton() {
        btnUnlock.visibility = View.VISIBLE
        handler.removeCallbacks(unlockHideRunnable)
        handler.postDelayed(unlockHideRunnable, 2500)
    }

    private fun showOsd(text: String, durationMs: Long = 900L) {
        tvOsd.text = text
        tvOsd.visibility = View.VISIBLE
        handler.removeCallbacks(osdHideRunnable)
        handler.postDelayed(osdHideRunnable, durationMs)
    }

    private fun currentItem(): VideoItem? =
        if (::player.isInitialized) items.getOrNull(player.currentMediaItemIndex) else null

    private fun updateTitle() {
        tvTitle.text = currentItem()?.name ?: ""
    }

    private fun updatePlayIcon() {
        val showPause = player.playWhenReady && player.playbackState != Player.STATE_ENDED
        btnPlay.setImageResource(if (showPause) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateProgress() {
        if (!::player.isInitialized) return
        val dur = player.duration
        val total = if (dur == C.TIME_UNSET || dur < 0) 0L else dur
        val pos = player.currentPosition
        if (!dragging) {
            seekBar.max = total.toInt()
            seekBar.progress = pos.toInt()
            seekBar.secondaryProgress = player.bufferedPosition.toInt()
            tvPosition.text = formatTime(pos)
        }
        tvRemaining.text = "-" + formatTime(total - pos)
        if (abA >= 0 && abB >= 0 && pos >= abB) {
            player.seekTo(abA)
        }
    }

    private fun updateClock() {
        val s = DateFormat.getTimeFormat(this).format(Date())
        if (s != lastClock) {
            lastClock = s
            updateStatusText()
        }
    }

    private fun updateStatusText() {
        val batt = if (batteryPct >= 0) {
            batteryPct.toString() + "%" + (if (charging) " \u26A1" else "")
        } else {
            ""
        }
        tvBattery.text = batt
        tvBattery.visibility = if (batt.isEmpty()) View.GONE else View.VISIBLE
        tvClock.text = lastClock
        miniStatus.text = if (batt.isEmpty()) lastClock else lastClock + "  \u2022  " + batt
    }

    private fun updateMiniVisibility() {
        val show = Prefs.showStatus(this) && controls.visibility != View.VISIBLE && !inPip
        miniStatus.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun updateMoreLabels() {
        val id = player.currentMediaItem?.mediaId
        val fav = id != null && Prefs.isFavorite(this, id)
        bFavorite.text = if (fav) "\u2605 Favorite" else "\u2606 Favorite"
        bAbRepeat.text = when {
            abA < 0 -> "AB Repeat"
            abB < 0 -> "AB Repeat\nA " + formatTime(abA)
            else -> "AB Repeat\n" + formatTime(abA) + " - " + formatTime(abB)
        }
        bNight.text = if (nightOn) "Night mode\nON" else "Night mode"
        bMirror.text = if (mirrorOn) "Mirror mode\nON" else "Mirror mode"
        bTimer.text = if (sleepMinutes > 0) "Timer\n$sleepMinutes min" else "Timer"
        bLoop.text = "Loop\n" + when (loopMode) {
            LOOP_ONE -> "One"
            LOOP_NEXT -> "Next"
            LOOP_ALL -> "All"
            else -> "Off"
        }
        bBoost.text = if (boostDb > 0) "Volume boost\n+$boostDb dB" else "Volume boost"
        bStatus.text = if (Prefs.showStatus(this)) "Clock & battery\nON" else "Clock & battery\nOFF"
    }

    // ------------------------------------------------------------------ zoom

    private fun setZoom(z: Float) {
        zoom = z.coerceIn(1f, 5f)
        if (zoom <= 1.01f) {
            zoom = 1f
            panX = 0f
            panY = 0f
        }
        applyZoom()
    }

    private fun applyZoom() {
        val maxX = (zoom - 1f) * root.width / 2f
        val maxY = (zoom - 1f) * root.height / 2f
        panX = panX.coerceIn(-maxX, maxX)
        panY = panY.coerceIn(-maxY, maxY)
        playerView.scaleX = zoom
        playerView.scaleY = zoom
        playerView.translationX = panX
        playerView.translationY = panY
    }

    // ------------------------------------------------------------------ playback helpers

    private fun togglePlay() {
        val playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED
        if (playing) {
            player.pause()
        } else {
            val dur = player.duration
            val atEnd = player.playbackState == Player.STATE_ENDED ||
                (dur > 0 && dur != C.TIME_UNSET && player.currentPosition >= dur - 300)
            if (atEnd) player.seekTo(player.currentMediaItemIndex, 0L)
            player.play()
        }
    }

    private fun seekBy(deltaMs: Long) {
        val dur = player.duration
        val max = if (dur == C.TIME_UNSET || dur < 0) Long.MAX_VALUE else dur
        player.seekTo((player.currentPosition + deltaMs).coerceIn(0L, max))
        showOsd(if (deltaMs > 0) "+10s" else "-10s")
    }

    private fun speedFromStep(step: Int): Float = (25 + step * 5) / 100f

    private fun applySpeedStep(step: Int) {
        speedStep = step.coerceIn(0, 75)
        val speed = speedFromStep(speedStep)
        player.setPlaybackSpeed(speed)
        tvSpeedValue.text = String.format(Locale.US, "%.2f X", speed)
        btnSpeed.text = String.format(Locale.US, "%.2fx", speed)
        if (speedSeek.progress != speedStep) speedSeek.progress = speedStep
    }

    private fun applyLoopMode() {
        when (loopMode) {
            LOOP_ONE -> {
                player.repeatMode = Player.REPEAT_MODE_ONE
                player.setPauseAtEndOfMediaItems(false)
            }
            LOOP_NEXT -> {
                player.repeatMode = Player.REPEAT_MODE_OFF
                player.setPauseAtEndOfMediaItems(false)
            }
            LOOP_ALL -> {
                player.repeatMode = Player.REPEAT_MODE_ALL
                player.setPauseAtEndOfMediaItems(false)
            }
            else -> {
                // loop off: stop when this video ends instead of jumping to the next one
                player.repeatMode = Player.REPEAT_MODE_OFF
                player.setPauseAtEndOfMediaItems(true)
            }
        }
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (e: Exception) {
            0.5f
        }
    }

    private fun setBrightness(value: Float) {
        val lp = window.attributes
        lp.screenBrightness = value
        window.attributes = lp
    }

    private fun saveResume() {
        val item = player.currentMediaItem ?: return
        val dur = player.duration
        val pos = player.currentPosition
        val nearEnd = dur > 0 && pos > dur - 5000
        Prefs.setResume(this, item.mediaId, if (nearEnd) 0L else pos)
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            val size = player.videoSize
            val w = if (size.width > 0) size.width else 16
            val h = if (size.height > 0) size.height else 9
            val ratio = w.toFloat() / h.toFloat()
            val rational = when {
                ratio > 2.39f -> Rational(239, 100)
                ratio < 0.5f -> Rational(1, 2)
                else -> Rational(w, h)
            }
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(rational).build()
                )
            } catch (e: Exception) {
                toast("Picture-in-picture is not available")
            }
        } else {
            toast("Picture-in-picture is not supported on this phone")
        }
    }

    // ------------------------------------------------------------------ file actions from the player

    private fun showFileMenu() {
        val item = currentItem() ?: return
        actions.showMenu(item, false, fileListener)
    }

    private fun removeFromPlaylist(item: VideoItem) {
        val idx = items.indexOfFirst { it.uri == item.uri }
        if (idx < 0) return
        if (items.size == 1) {
            finish()
            return
        }
        if (idx == player.currentMediaItemIndex && idx == items.size - 1) {
            player.seekTo(idx - 1, 0L)
        }
        player.removeMediaItem(idx)
        items.removeAt(idx)
        updateTitle()
    }

    private fun handleRenamed(old: VideoItem, updated: VideoItem) {
        val idx = items.indexOfFirst { it.uri == old.uri }
        if (idx < 0) return
        items[idx] = updated
        if (updated.uri != old.uri) {
            // the file moved to a new address, so the player needs the new one
            val pos = player.currentPosition
            val isCurrent = idx == player.currentMediaItemIndex
            player.replaceMediaItem(idx, buildMediaItem(updated))
            if (isCurrent) player.seekTo(idx, pos)
        }
        updateTitle()
    }

    // ------------------------------------------------------------------ screenshot

    private fun takeScreenshot() {
        val tv = playerView.videoSurfaceView as? TextureView
        if (tv == null) {
            toast("Screenshot is not available")
            return
        }
        val frame: Bitmap? = try {
            tv.bitmap
        } catch (e: Exception) {
            null
        }
        if (frame == null) {
            toast("Could not capture the picture")
            return
        }
        val shot = if (mirrorOn) {
            val m = Matrix()
            m.postScale(-1f, 1f)
            Bitmap.createBitmap(frame, 0, 0, frame.width, frame.height, m, true)
        } else {
            frame
        }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        showOsd("Screenshot")
        Thread {
            val res = MediaSaver.saveBitmap(this, shot, "Screenshot_$stamp.png")
            runOnUiThread {
                toast(if (res != null) "Screenshot saved in $res" else "Could not save the screenshot")
            }
        }.start()
    }

    // ------------------------------------------------------------------ picture, audio boost, subtitles

    private fun applyPicture() {
        val tv = playerView.videoSurfaceView as? TextureView ?: return
        if (pBrightness == 0 && pContrast == 100 && pSaturation == 100) {
            tv.setLayerType(View.LAYER_TYPE_NONE, null)
            return
        }
        val cm = ColorMatrix()
        cm.setSaturation(pSaturation / 100f)
        val c = pContrast / 100f
        val b = pBrightness * 2.55f + (1f - c) * 128f
        val adjust = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, b,
                0f, c, 0f, 0f, b,
                0f, 0f, c, 0f, b,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(adjust)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun savePicture() {
        Prefs.putInt(this, "pic_brightness", pBrightness)
        Prefs.putInt(this, "pic_contrast", pContrast)
        Prefs.putInt(this, "pic_saturation", pSaturation)
    }

    private fun showPictureDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))

        fun addSlider(title: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
            val label = TextView(this)
            label.text = title
            label.setTextColor(Color.WHITE)
            label.setPadding(0, dp(10), 0, 0)
            val bar = SeekBar(this)
            bar.max = max - min
            bar.progress = value - min
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) onChange(progress + min)
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            box.addView(label)
            box.addView(bar)
            return bar
        }

        val sbBright = addSlider("Brightness", -50, 50, pBrightness) {
            pBrightness = it
            applyPicture()
        }
        val sbContrast = addSlider("Contrast", 50, 150, pContrast) {
            pContrast = it
            applyPicture()
        }
        val sbSat = addSlider("Saturation", 0, 200, pSaturation) {
            pSaturation = it
            applyPicture()
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(14), 0, 0)

        fun chip(text: String): TextView {
            val t = TextView(this)
            t.text = text
            t.setTextColor(Color.WHITE)
            t.gravity = android.view.Gravity.CENTER
            t.setBackgroundResource(R.drawable.bg_chip_glass)
            t.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(t, lp)
            return t
        }

        val reset = chip("Reset")
        val enhance = chip("Enhance")
        reset.setOnClickListener {
            pBrightness = 0
            pContrast = 100
            pSaturation = 100
            sbBright.progress = 50
            sbContrast.progress = 50
            sbSat.progress = 100
            applyPicture()
        }
        enhance.setOnClickListener {
            // a gentle lift that helps dull, low-quality video without crushing details
            pBrightness = 3
            pContrast = 112
            pSaturation = 115
            sbBright.progress = 53
            sbContrast.progress = 62
            sbSat.progress = 115
            applyPicture()
        }
        box.addView(row)

        AlertDialog.Builder(this)
            .setTitle("Picture")
            .setView(box)
            .setPositiveButton("Done", null)
            .setOnDismissListener { savePicture() }
            .show()
    }

    private fun applyBoost() {
        if (boostDb == 0 && enhancer == null) return
        try {
            val e = enhancer ?: LoudnessEnhancer(player.audioSessionId)
            enhancer = e
            e.setTargetGain(boostDb * 100)
            e.setEnabled(boostDb > 0)
        } catch (ex: Exception) {
            toast("Volume boost is not available on this phone")
        }
    }

    private fun showBoostDialog() {
        val labels = arrayOf("Off", "+3 dB (louder)", "+6 dB (much louder)", "+9 dB (maximum, may distort)")
        val gains = intArrayOf(0, 3, 6, 9)
        val checked = gains.indexOf(boostDb).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Volume boost")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                boostDb = gains[which]
                applyBoost()
                updateMoreLabels()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun applySubtitleStyle() {
        val sv = playerView.subtitleView ?: return
        sv.setFractionalTextSize(subSizes[subSizeIndex])
        sv.setStyle(
            CaptionStyleCompat(
                Color.WHITE,
                Color.TRANSPARENT,
                Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                Color.BLACK,
                null
            )
        )
    }

    private fun showSubtitleSizeDialog() {
        AlertDialog.Builder(this)
            .setTitle("Subtitle size")
            .setSingleChoiceItems(subSizeNames, subSizeIndex) { dialog, which ->
                dialog.dismiss()
                subSizeIndex = which
                Prefs.putInt(this, "sub_size", which)
                applySubtitleStyle()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ------------------------------------------------------------------ dialogs

    private fun trackLabel(f: Format, number: Int, isAudio: Boolean): String {
        val lang = f.language
        val langName = if (lang != null && lang != "und") {
            Locale(lang).displayLanguage.takeIf { it.isNotBlank() && !it.equals(lang, ignoreCase = true) }
        } else {
            null
        }
        val sb = StringBuilder()
        sb.append(f.label ?: langName ?: ("Track " + (number + 1)))
        if (isAudio) {
            val codec = f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            if (!codec.isNullOrBlank()) sb.append(" \u00B7 ").append(codec)
            if (f.channelCount > 0) sb.append(" \u00B7 ").append(f.channelCount).append("ch")
        }
        return sb.toString()
    }

    private fun showTrackDialog(type: Int) {
        val isText = type == C.TRACK_TYPE_TEXT
        val entries = ArrayList<TrackEntry>()
        for (g in player.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(
                    TrackEntry(g, i, trackLabel(g.getTrackFormat(i), entries.size, !isText), g.isTrackSelected(i))
                )
            }
        }
        if (entries.isEmpty() && !isText) {
            toast("No audio tracks found")
            return
        }

        val labels = ArrayList<String>()
        if (isText) labels.add("Off")
        val offset = labels.size
        var checked = -1
        for ((n, e) in entries.withIndex()) {
            labels.add(e.label)
            if (e.selected) checked = n + offset
        }
        if (isText) {
            val disabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
            if (disabled || checked < 0) checked = 0
            labels.add("Load subtitle file\u2026")
        } else {
            labels.add("Save audio as a separate file\u2026")
        }
        val lastIndex = labels.size - 1

        AlertDialog.Builder(this)
            .setTitle(if (isText) "Subtitles" else "Audio track")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { dialog, which ->
                dialog.dismiss()
                if (isText && which == 0) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        .build()
                } else if (isText && which == lastIndex) {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    i.type = "*/*"
                    startActivityForResult(i, REQ_SUBTITLE)
                } else if (!isText && which == lastIndex) {
                    extractAudio()
                } else {
                    val e = entries[which - offset]
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(type, false)
                        .setOverrideForType(TrackSelectionOverride(e.group.mediaTrackGroup, e.index))
                        .build()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (actions.onActivityResult(requestCode, resultCode)) return
        if (requestCode == REQ_SUBTITLE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // fine, we only need the file for this session
            }
            addExternalSubtitle(uri)
        }
    }

    private fun addExternalSubtitle(uri: Uri) {
        val current = player.currentMediaItem ?: return
        val name = queryName(this, uri).lowercase(Locale.ROOT)
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val subtitle = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val index = player.currentMediaItemIndex
        val position = player.currentPosition
        val updated = current.buildUpon().setSubtitleConfigurations(listOf(subtitle)).build()
        player.replaceMediaItem(index, updated)
        player.seekTo(index, position)
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        toast("Subtitle loaded")
    }

    private fun showPlaylistDialog() {
        val titles = Array(items.size) { i -> items[i].name }
        AlertDialog.Builder(this)
            .setTitle("Playlist")
            .setSingleChoiceItems(titles, player.currentMediaItemIndex) { dialog, which ->
                dialog.dismiss()
                player.seekTo(which, 0L)
                player.play()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showTimerDialog() {
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val minutes = intArrayOf(0, 15, 30, 45, 60, 90)
        val checked = minutes.indexOf(sleepMinutes).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                handler.removeCallbacks(sleepRunnable)
                sleepMinutes = minutes[which]
                if (sleepMinutes > 0) {
                    handler.postDelayed(sleepRunnable, sleepMinutes * 60_000L)
                    toast("Video will pause in $sleepMinutes minutes")
                } else {
                    toast("Timer off")
                }
                updateMoreLabels()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showLoopDialog() {
        val labels = arrayOf(
            "Off \u2013 stop when this video ends",
            "Repeat this video",
            "Play next videos, stop after the last",
            "Repeat all videos"
        )
        val modes = intArrayOf(LOOP_OFF, LOOP_ONE, LOOP_NEXT, LOOP_ALL)
        val checked = modes.indexOf(loopMode).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Loop")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                loopMode = modes[which]
                Prefs.putInt(this, "loop_mode", loopMode)
                applyLoopMode()
                updateMoreLabels()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showBookmarkDialog() {
        val id = player.currentMediaItem?.mediaId ?: return
        val marks = Prefs.bookmarks(this, id)
        val now = player.currentPosition
        val labels = ArrayList<String>()
        labels.add("+ Add bookmark at " + formatTime(now))
        for (m in marks) labels.add(formatTime(m))
        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) {
                    Prefs.addBookmark(this, id, now)
                    toast("Bookmark added")
                } else {
                    player.seekTo(marks[which - 1])
                }
            }
            .setNeutralButton("Clear all") { _, _ ->
                Prefs.clearBookmarks(this, id)
                toast("Bookmarks cleared")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showInfoDialog() {
        val item = currentItem()
        val sb = StringBuilder()
        if (item != null) {
            sb.append("Name: ").append(item.name).append('\n')
            if (item.sizeBytes > 0) sb.append("Size: ").append(formatSize(item.sizeBytes)).append('\n')
            if (item.isVault) sb.append("Location: private vault\n")
            else if (!item.path.isNullOrEmpty()) sb.append("Path: ").append(item.path).append('\n')
        }
        val dur = player.duration
        if (dur > 0 && dur != C.TIME_UNSET) sb.append("Duration: ").append(formatTime(dur)).append('\n')
        val vf = player.videoFormat
        if (vf != null) {
            if (vf.width > 0 && vf.height > 0) {
                sb.append("Resolution: ").append(vf.width).append(" x ").append(vf.height).append('\n')
            }
            if (vf.frameRate > 0f) {
                sb.append("Frame rate: ").append(String.format(Locale.US, "%.2f fps", vf.frameRate)).append('\n')
            }
            val vc = vf.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            if (!vc.isNullOrBlank()) sb.append("Video codec: ").append(vc).append('\n')
            if (vf.bitrate > 0) {
                sb.append("Video bitrate: ").append(vf.bitrate / 1000).append(" kbps").append('\n')
            }
        }
        val af = player.audioFormat
        if (af != null) {
            val ac = af.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            if (!ac.isNullOrBlank()) sb.append("Audio codec: ").append(ac).append('\n')
            if (af.channelCount > 0) sb.append("Audio channels: ").append(af.channelCount).append('\n')
            if (af.sampleRate > 0) sb.append("Sample rate: ").append(af.sampleRate).append(" Hz").append('\n')
        }
        AlertDialog.Builder(this)
            .setTitle("Video info")
            .setMessage(sb.toString().trim())
            .setPositiveButton("OK", null)
            .show()
    }

    private fun ensureEqualizer(): Equalizer? {
        if (equalizer != null) return equalizer
        return try {
            val eq = Equalizer(0, player.audioSessionId)
            equalizer = eq
            eq
        } catch (e: Exception) {
            null
        }
    }

    private fun showEqualizerDialog() {
        val eq = ensureEqualizer()
        if (eq == null) {
            toast("Equalizer is not available on this phone")
            return
        }
        val range = eq.bandLevelRange
        val lo = range[0].toInt()
        val hi = range[1].toInt()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))

        val toggle = Switch(this)
        toggle.text = "Enable equalizer"
        toggle.setTextColor(Color.WHITE)
        toggle.textSize = 17f
        toggle.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        toggle.isChecked = eq.enabled
        toggle.setOnCheckedChangeListener { _, checked -> eq.setEnabled(checked) }
        box.addView(toggle)

        for (b in 0 until eq.numberOfBands.toInt()) {
            val band = b.toShort()
            val label = TextView(this)
            label.text = (eq.getCenterFreq(band) / 1000).toString() + " Hz"
            label.setTextColor(Color.WHITE)
            label.textSize = 16f
            label.setTypeface(label.typeface, android.graphics.Typeface.BOLD)
            label.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            label.setPadding(0, dp(12), 0, 0)
            box.addView(label)

            val bar = SeekBar(this)
            bar.max = hi - lo
            bar.progress = eq.getBandLevel(band).toInt() - lo
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) eq.setBandLevel(band, (progress + lo).toShort())
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            box.addView(bar)
        }

        AlertDialog.Builder(this)
            .setTitle("Equalizer")
            .setView(box)
            .setPositiveButton("Done", null)
            .show()
    }

    // ------------------------------------------------------------------ extract audio

    private fun extractAudio() {
        val item = currentItem() ?: return
        val src = player.currentMediaItem?.localConfiguration?.uri ?: return
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src)).setRemoveVideo(true).build()
        val outFile = File(cacheDir, "audio_" + System.currentTimeMillis() + ".m4a")
        val dot = item.name.lastIndexOf('.')
        val base = (if (dot > 0) item.name.substring(0, dot) else item.name)
            .replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifEmpty { "audio" }

        val box = LinearLayout(this)
        box.gravity = android.view.Gravity.CENTER
        box.setPadding(dp(24), dp(16), dp(24), dp(16))
        box.addView(ProgressBar(this))
        val dlg = AlertDialog.Builder(this)
            .setTitle("Extracting audio\u2026")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Cancel") { _, _ ->
                try {
                    transformer?.cancel()
                } catch (e: Exception) {
                    // ignore
                }
                outFile.delete()
            }
            .show()

        val t = Transformer.Builder(this)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    dlg.dismiss()
                    Thread {
                        val res = MediaSaver.saveFile(
                            this@PlayerActivity, outFile, "$base.m4a", "audio/mp4",
                            MediaSaver.Kind.AUDIO, "VideoPlayer"
                        )
                        outFile.delete()
                        runOnUiThread {
                            toast(if (res != null) "Audio saved in $res" else "Could not save the audio file")
                        }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    dlg.dismiss()
                    outFile.delete()
                    toast("Could not extract audio: " + exportException.errorCodeName)
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
    }

    // ------------------------------------------------------------------ cut (trim) a clip

    private fun showCutDialog() {
        val info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.setPadding(0, 0, 0, dp(12))

        fun refresh() {
            val s = if (cutStart >= 0) formatTime(cutStart) else "--:--"
            val e = if (cutEnd >= 0) formatTime(cutEnd) else "--:--"
            info.text = "Start: $s      End: $e"
        }
        refresh()

        val btnStart = TextView(this)
        btnStart.text = "Set start = current position"
        btnStart.setTextColor(Color.WHITE)
        btnStart.setBackgroundResource(R.drawable.bg_chip_glass)
        btnStart.setPadding(dp(14), dp(12), dp(14), dp(12))
        btnStart.setOnClickListener {
            cutStart = player.currentPosition
            refresh()
        }

        val btnEnd = TextView(this)
        btnEnd.text = "Set end = current position"
        btnEnd.setTextColor(Color.WHITE)
        btnEnd.setBackgroundResource(R.drawable.bg_chip_glass)
        btnEnd.setPadding(dp(14), dp(12), dp(14), dp(12))
        btnEnd.setOnClickListener {
            cutEnd = player.currentPosition
            refresh()
        }

        val gap = dp(8)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), dp(8))
        box.addView(info)
        box.addView(btnStart)
        val lpEnd = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lpEnd.topMargin = gap
        box.addView(btnEnd, lpEnd)

        AlertDialog.Builder(this)
            .setTitle("Cut a clip")
            .setView(box)
            .setPositiveButton("Save clip") { _, _ -> startCut() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun startCut() {
        if (cutStart < 0 || cutEnd <= cutStart) {
            toast("Set a start and an end first (end must be after start)")
            return
        }
        val sourceUri = player.currentMediaItem?.localConfiguration?.uri ?: return
        val clipped = MediaItem.Builder()
            .setUri(sourceUri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(cutStart)
                    .setEndPositionMs(cutEnd)
                    .build()
            )
            .build()
        val edited = EditedMediaItem.Builder(clipped).build()
        val outFile = File(cacheDir, "clip_" + System.currentTimeMillis() + ".mp4")

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    Thread {
                        val res = MediaSaver.saveFile(
                            this@PlayerActivity, outFile, outFile.name, "video/mp4",
                            MediaSaver.Kind.VIDEO, "VideoPlayer"
                        )
                        outFile.delete()
                        runOnUiThread {
                            toast(if (res != null) "Clip saved in $res" else "Could not save the clip")
                        }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    toast("Could not cut this video: " + exportException.errorCodeName)
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        toast("Saving clip, please wait\u2026")
    }
}
